-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Aug 03, 2009 at 05:21 AM
-- Server version: 4.0.26
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `songs270_en`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `info_best_visitors`
-- 

CREATE TABLE `info_best_visitors` (
  `time` text NOT NULL,
  `v_count` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `info_best_visitors`
-- 

INSERT INTO `info_best_visitors` (`time`, `v_count`) VALUES ('29-Nov-2008  : 08:50', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_browser`
-- 

CREATE TABLE `info_browser` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `info_browser`
-- 

INSERT INTO `info_browser` (`name`, `count`) VALUES ('Netscape', 30);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('MSIE', 7951);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Lynx', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Opera', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('WebTV', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Konqueror', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Bot', 0);
INSERT INTO `info_browser` (`name`, `count`) VALUES ('Other', 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_hits`
-- 

CREATE TABLE `info_hits` (
  `date` text NOT NULL,
  `hits` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `info_hits`
-- 

INSERT INTO `info_hits` (`date`, `hits`) VALUES ('29-11-2008', 162);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('30-11-2008', 310);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('02-12-2008', 376);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('05-12-2008', 432);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('06-12-2008', 595);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('07-12-2008', 357);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('08-12-2008', 891);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('09-12-2008', 879);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('10-12-2008', 1297);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('11-12-2008', 1127);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('12-12-2008', 868);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('13-12-2008', 62);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('15-12-2008', 556);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('17-12-2008', 12);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('28-12-2008', 5);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('17-03-2009', 1);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('29-03-2009', 13);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('16-05-2009', 21);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('24-06-2009', 13);
INSERT INTO `info_hits` (`date`, `hits`) VALUES ('03-08-2009', 10);

-- --------------------------------------------------------

-- 
-- Table structure for table `info_online`
-- 

CREATE TABLE `info_online` (
  `time` int(15) NOT NULL default '0',
  `ip` varchar(40) NOT NULL default '',
  PRIMARY KEY  (`time`),
  KEY `ip` (`ip`)
) ;

-- 
-- Dumping data for table `info_online`
-- 

INSERT INTO `info_online` (`time`, `ip`) VALUES (1249266070, '127.0.0.1');

-- --------------------------------------------------------

-- 
-- Table structure for table `info_os`
-- 

CREATE TABLE `info_os` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `info_os`
-- 

INSERT INTO `info_os` (`name`, `count`) VALUES ('Windows', 7981);
INSERT INTO `info_os` (`name`, `count`) VALUES ('Mac', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('Linux', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('FreeBSD', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('SunOS', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('IRIX', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('BeOS', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('OS/2', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('AIX', 0);
INSERT INTO `info_os` (`name`, `count`) VALUES ('Other', 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_adv`
-- 

CREATE TABLE `songs_adv` (
  `id` int(11) NOT NULL auto_increment,
  `type` text NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `songs_adv`
-- 

INSERT INTO `songs_adv` (`id`, `type`, `content`) VALUES (1, 'header', '');
INSERT INTO `songs_adv` (`id`, `type`, `content`) VALUES (2, 'footer', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_albums`
-- 

CREATE TABLE `songs_albums` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` text NOT NULL,
  `img` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=25 ;

-- 
-- Dumping data for table `songs_albums`
-- 

INSERT INTO `songs_albums` (`id`, `cat`, `name`, `img`) VALUES (4, 5, 'Hekyo Einayk', '');
INSERT INTO `songs_albums` (`id`, `cat`, `name`, `img`) VALUES (18, 16, 'Enjannet', '');
INSERT INTO `songs_albums` (`id`, `cat`, `name`, `img`) VALUES (16, 1, 'Bastanak', '');
INSERT INTO `songs_albums` (`id`, `cat`, `name`, `img`) VALUES (20, 49, 'Lek Lewahdk', 'uploads/albums/samo-08.jpg');
INSERT INTO `songs_albums` (`id`, `cat`, `name`, `img`) VALUES (21, 49, 'Aref Leh', 'uploads/albums/samo-07.jpg');
INSERT INTO `songs_albums` (`id`, `cat`, `name`, `img`) VALUES (22, 12, 'Yemken', 'uploads/singers/assi-el7ellani.gif');
INSERT INTO `songs_albums` (`id`, `cat`, `name`, `img`) VALUES (23, 51, 'Andy', '');
INSERT INTO `songs_albums` (`id`, `cat`, `name`, `img`) VALUES (24, 52, 'Ghamadt Einy', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_banners`
-- 

CREATE TABLE `songs_banners` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `ord` int(11) NOT NULL default '0',
  `type` text NOT NULL,
  `views` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `menu_id` int(11) NOT NULL default '0',
  `menu_pos` text NOT NULL,
  `pages` text NOT NULL,
  `content` text NOT NULL,
  `c_type` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=16 ;

-- 
-- Dumping data for table `songs_banners`
-- 

INSERT INTO `songs_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `active`) VALUES (1, 'Allomani Programming Services', 'http://allomani.biz', 'http://allomani.biz/allomani_banner.gif', '2006-06-10 01:00:00', 1, 'footer', 41328, 33, 0, 'l', 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,', '', 'img', 1);
INSERT INTO `songs_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `active`) VALUES (2, 'Allomani Programming Services', 'http://allomani.biz/', 'http://allomani.biz/allomani_banner.gif', '0000-00-00 00:00:00', 0, 'header', 69565, 22, 0, 'l', 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,', '', 'img', 1);
INSERT INTO `songs_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `active`) VALUES (13, 'Allomani Programming Services', 'http://', '', '2008-11-30 08:47:50', 1, 'listen', 23, 0, 0, 'r', 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,', '<?\r\nglobal $_SERVER;\r\nprint "<br><center> $_SERVER[HTTP_HOST]</center><br>";\r\n?>', 'code', 1);
INSERT INTO `songs_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `active`) VALUES (14, 'Allomani Programming Services', 'http://', '', '2008-12-06 21:07:45', 1, 'header', 6, 0, 0, 'r', 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,', '', 'img', 0);
INSERT INTO `songs_banners` (`id`, `title`, `url`, `img`, `date`, `ord`, `type`, `views`, `clicks`, `menu_id`, `menu_pos`, `pages`, `content`, `c_type`, `active`) VALUES (15, 'Allomani Programming Services', 'http://allomani.biz/', 'http://allomani.biz/allomani_banner.gif', '2008-12-06 21:56:14', 0, 'listen', 11, 0, 0, 'r', 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,', '', 'img', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_blocks`
-- 

CREATE TABLE `songs_blocks` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `pos` text NOT NULL,
  `file` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `template` int(11) NOT NULL default '0',
  `pages` text NOT NULL,
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `file` (`file`),
  FULLTEXT KEY `file_2` (`file`),
  FULLTEXT KEY `file_3` (`file`),
  FULLTEXT KEY `file_4` (`file`),
  FULLTEXT KEY `file_5` (`file`),
  FULLTEXT KEY `file_6` (`file`),
  FULLTEXT KEY `file_7` (`file`),
  FULLTEXT KEY `file_8` (`file`)
)  AUTO_INCREMENT=37 ;

-- 
-- Dumping data for table `songs_blocks`
-- 

INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (10, 'Search', 'l', '<form method="postt" action="index.php">\r\n<input type=text name="keyword" size="12" tabindex="1">\r\n<input type=hidden name="action" value="search">\r\n<select name=op>\r\n<option value=''songs''>Songs</option>\r\n<option value=''singers''>Singers</option>\r\n<option value=''videos''> Videos </option>\r\n<option value=''news''> News </option>\r\n</select>\r\n<input type=submit value="Search" tabindex="1">\r\n</form>', 7, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (8, 'Main Menu', 'l', '<b>::</b> <a href=''index.php''>Main Page</a><br>\r\n<b>::</b> <a href=''index.php?action=news''>News</a><br>\r\n<b>::</b> <a href=''index.php?action=statics''>Statics</a><br>\r\n<b>::</b> <a href=''sitemap.xml''>Sitemap</a><br>\r\n<b>::</b> <a href=''index.php?action=contactus''>Contact us</a><br>\r\n ', 0, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (17, 'Songs Categories', 'l', '<?\r\n$cats_qr=db_query("select * from songs_cats where active=1 order by ord asc");\r\nwhile($data = db_fetch($cats_qr)){\r\n       print "<b>::</b> <a href=''".get_template(''links_browse_cat'',''{id}'',$data[id])."''>$data[name]</a><br>";\r\n\r\n\r\n        }\r\n', 1, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (11, 'Votes', 'r', '<?\r\n$qr_title = db_query("select * from songs_votes_cats  where active=1");\r\nif(db_num($qr_title)){\r\n\r\n$data_title = db_fetch($qr_title);\r\nprint "<center>$data_title[title]</center>";\r\n$qr = mysql_query("select * from songs_votes where cat=$data_title[id]");\r\nprint "<form action=\\"index.php\\" method=\\"post\\">\r\n<input type=''hidden'' name=''action'' value=''vote_add''>\r\n";\r\n\r\n while ($data = mysql_fetch_array($qr)){\r\n\r\n        print "<input type=''radio'' value=''$data[id]'' name=''vote_id''>$data[title]<br>";\r\n\r\n\r\n\r\n }\r\nprint "<center><br><input type=''submit'' value=''Vote''> <br><br><a href=''index.php?action=votes''>Results </a></center></form>";\r\n}else{\r\nprint "<center>  No Votes </center>";\r\n}\r\n?>', 1, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (2, 'Most Downloaded', 'r', '<?\r\n \r\n$qr1=db_query("select *  from songs_urls_data order by downloads DESC limit 10");\r\n\r\n  $c = 0 ;\r\nwhile($data2=db_fetch($qr1)){\r\n\r\n$song_data = db_qr_fetch("select *  from songs_songs where id=''$data2[song_id]''");\r\n\r\n$singer_data = db_qr_fetch("select * from songs_singers where id=''$song_data[album]''");\r\n\r\n            ++$c ;\r\n          print "$c.<a href=''".get_template(''links_song_download'',array(''{id}'',''{cat}''),array($data2[''song_id''],$data2[''cat'']))."''>$singer_data[name] - $song_data[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 4, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (4, 'Online', 'l', '<?\r\nglobal $counter ;\r\n\r\nprint "<p align=center> $counter[online_users]  Visitor Browsing Now </p>";\r\n\r\nprint "<p align=center>Best Visitors Count : $counter[best_visit] at : <br> $counter[best_visit_time] <br></p>";\r\n\r\n', 9, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (13, 'Last Updates', 'c', '<?\r\nglobal $new_limit,$settings,$data;\r\n$sigers_array = array();   \r\n\r\n\r\nprint "<table width=100%><tr>";\r\n$c=0 ;\r\n$qr=db_query("select name,id,last_update,img from songs_singers where active=1 order by last_update desc limit 8") ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\nprint "<td valign=top>";\r\ncompile_template(get_template(''browse_singers''));\r\nprint "</td>";\r\n              }\r\n\r\nprint "</tr></table>";\r\n?>', 0, 1, 0, 'main,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (18, 'Last News', 'c', '<?\r\nglobal $data;\r\n$qr = db_query("select * from songs_news order by id DESC limit 4");\r\n\r\nprint "<table width=100%><tr>" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\n\r\n\r\nprint "<tr><td>";\r\ncompile_template(get_template(''browse_news''));  \r\nprint "<hr width=90% class=separate_line size=\\"1\\"></td></tr>";\r\n\r\n        }\r\nprint "</tr></table>";\r\n       ?>', 4, 1, 0, 'main,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (19, 'Top Videos Downloads', 'r', '<?\r\n\r\n$qr1=db_query("select *  from songs_videos_data  order by downloads DESC limit 20");\r\n  $c = 0 ;\r\nwhile($data2=db_fetch($qr1)){\r\n\r\n      ++$c;\r\n          print "$c.<a href=''".get_template(''links_video_download'',''{id}'',$data2[''id''])."''>$data2[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 5, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (20, 'New Videos', 'c', '<?\r\nglobal $settings,$data ;\r\n$qr=db_query("select * from songs_videos_data order by id DESC limit 8") ;\r\nprint "<table width=100%><tr>";\r\n$c=0 ;\r\nwhile ($data = db_fetch($qr)){\r\n\r\n   \r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n compile_template(get_template(''browse_videos''));   \r\n\r\n              }\r\n             print "</tr></table>";?>', 2, 1, 0, 'main,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (21, 'Videos Categories', 'l', '<?\r\n$cats_qr=db_query("select * from songs_videos_cats where active=1 order by ord asc");\r\nwhile($data = db_fetch($cats_qr)){\r\n       print "<b>::</b> <a href=''".get_template(''links_browse_videos'',''{id}'',$data[''id''])."''>$data[name]</a><br>";\r\n\r\n\r\n        }', 2, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (26, 'New Albums', 'c', '<?\r\nglobal $settings,$data,$data_singer,$album_songs_num;\r\n\r\n$qr=mysql_query("select * from songs_albums  order by id DESC limit 8") ;\r\nprint "<table width=100%><tr>";\r\n\r\n$c=0 ;\r\n\r\n\r\nwhile ($data =db_fetch($qr)){\r\n\r\n$data_singer=db_qr_fetch("select * from songs_singers where id=$data[cat] and active=1") ;\r\n\r\nif($data_singer[''active'']){  \r\nif ($c==$settings[''songs_cells'']) {\r\nprint "  </tr><TR>" ;\r\n$c = 0 ;\r\n}\r\n ++$c ;\r\n\r\nprint "<td valign=top>";\r\n\r\n\r\n$album_songs_count = db_qr_fetch("select count(id) as count from songs_songs where album_id=''$data[id]'' and album=''$data_singer[id]''");\r\n$album_songs_num = $album_songs_count[''count''];\r\n\r\nif (!$data[''img'']){\r\n$data[''img''] = $data_singer[''img''];\r\n}\r\n$id = $data_singer[''id''];\r\ncompile_template(get_template(''browse_albums''));\r\n\r\nprint "</td>";\r\n}\r\n              \r\n}\r\n             print "</tr></table>";\r\n?>', 1, 1, 0, 'main,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (22, 'Most Voted', 'r', '<?\r\n\r\n$qr1=db_query("select *  from songs_songs where votes > 0 order by (votes / votes_total) DESC limit 10");\r\n\r\n  $c = 0 ;\r\nwhile($data2=db_fetch($qr1)){\r\n\r\n        $singer_data = db_qr_fetch("select * from songs_singers where id=$data2[album]");\r\n\r\n            ++$c ;\r\n          print "$c.<a href=''".get_template(''links_song_download'',array(''{id}'',''{cat}''),array($data2[''id''],''1''))."''>$singer_data[name] - $data2[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 2, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (23, 'Statics', 'l', '<?\r\nglobal $phrases;\r\n\r\n $data1 = db_qr_fetch("select count(id) as count from songs_singers");\r\n  $data3 = db_qr_fetch("select count(id) as count from songs_songs");\r\n   $data5 = db_qr_fetch("select count(id) as count from songs_videos_data");\r\n\r\n\r\nprint "\r\n\r\n<b> $phrases[singers_count] : </b> $data1[count] <br> <b>  $phrases[songs_count] : </b> $data3[count] <br> <b> $phrases[videos_count] : </b> $data5[count] \r\n";\r\n?>', 6, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (24, 'New', 'r', '<?\r\n$qr = db_query("select * from songs_new_menu order by ord asc");\r\nprint "<center>";\r\n\r\nwhile($data=db_fetch($qr)){\r\n\r\nif($data[''type'']=="singer"){\r\n$qr2=db_query("select * from songs_singers where id=$data[cat] and active=1");\r\nif(db_num($qr2)){\r\n$data2 = db_fetch($qr2);\r\nprint "<a href=''".get_template(''links_browse_songs'',"{id}",$data2[''id''])."''><img width=50 hieght=50 src=''".get_image($data2[''img''])."'' alt=''$data2[name]'' border=0></a><br>$data2[name]<br><br>";\r\n}\r\n\r\n}else{\r\n$qr2=db_query("select songs_albums.*,songs_singers.id as singer_id ,songs_singers.name as singer_name,songs_singers.img as singer_img from songs_singers,songs_albums where songs_albums.cat = songs_singers.id and songs_singers.active=1 and songs_albums.id=$data[cat]");\r\n\r\nif(db_num($qr2)){\r\n$data2 = db_fetch($qr2);\r\nprint "<a href=''".get_template(''links_browse_songs_w_album'',array(''{id}'',''{album_id}''),array($data2[''singer_id''],$data2[''id'']))."''><img width=50 hieght=50 src=''".get_image(iif($data2[''img''],$data2[''img''],$data2[''singer_img'']))."'' alt=''$data2[name]'' border=0></a><br>$data2[singer_name]<br>$data2[name]<br><br>";\r\n}\r\n}\r\n}\r\n', 0, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (25, 'Most Listened', 'r', '<?\r\n \r\n$qr1=db_query("select *  from songs_urls_data order by listens DESC limit 10");\r\n\r\n  $c = 0 ;\r\nwhile($data2=db_fetch($qr1)){\r\n\r\n$song_data = db_qr_fetch("select *  from songs_songs where id=''$data2[song_id]''");\r\n\r\n$singer_data = db_qr_fetch("select * from songs_singers where id=''$song_data[album]''");\r\n\r\n            ++$c ;\r\n          print "$c.<a href=''".get_template(''links_song_listen'',array(''{id}'',''{cat}''),array($data2[''song_id''],$data2[''cat'']))."''>$singer_data[name] - $song_data[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 3, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (27, 'Most Voted Videos', 'r', '<?\r\n\r\n$qr1=db_query("select *  from songs_videos_data  where votes > 0 order by (votes / votes_total)DESC limit 10");\r\n  $c = 0 ;\r\nwhile($data2=db_fetch($qr1)){\r\n\r\n      ++$c;\r\n          print "$c.<a href=''".get_template(''links_video_download'',''{id}'',$data2[''id''])."''>$data2[name]</a> </font><br>";\r\n        }\r\n\r\n\r\n?>', 6, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (31, 'Members', 'l', '<? if(check_member_login()){\r\nglobal $member_data ;\r\n\r\n\r\nprint "<center>  Welcome $member_data[username] <br> <br>" ;\r\n$nw_msgs = db_qr_fetch("select count(id) as count from songs_msgs where user = $member_data[id] and opened=0");\r\n\r\nif($nw_msgs[''count''] >0){\r\nprint "<font color=red> You Have $nw_msgs[count] New Messages</font><br><br>";\r\n}\r\n\r\nprint "<a href=''usercp.php''> Control Panel</a><br>\r\n<a href=''login.php?action=logout''>Logout</a>\r\n</center><br>";\r\n}else{\r\n?>\r\n<form method="POST" action="login.php">\r\n<input type=hidden name=action value=login>\r\n<input type=hidden name=re_link value="<? print $_SERVER[REQUEST_URI] ; ?>">\r\n<table border="0" width="100%">\r\n	<tr>\r\n		<td height="15"><span>Username :</span></td></tr><tr>\r\n		<td height="15"><input type="text" name="username" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="12"><span>Password :</span></td></tr><tr>\r\n		<td height="12" ><input type="password" name="password" size="10"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="23">\r\n		<p align="center"><input type="submit" value="Login"></td>\r\n	</tr>\r\n	<tr>\r\n		<td height="38"><span>\r\n		<a href="index.php?action=register">Register</a><br>\r\n		<a href="index.php?action=forget_pass">Forgot Your Password ?</a></span></td>\r\n	</tr>\r\n</table>\r\n</form>\r\n<?\r\n}\r\n\r\n?>', 3, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (32, 'Random Songs', 'l', '<? $qr = db_query("select id,name from songs_cats order by binary name asc");\r\nprint "<form action=random_list.php>\r\n<table><tr><td colspan=2>Category : </td></tr><tr><td colspan=2><select name=cat>\r\n<option value=''''>All Categories</option>" ;\r\n\r\nwhile($data = db_fetch($qr)){\r\nprint "<option value=''$data[id]''>$data[name]</option>";\r\n}\r\nprint "</select>\r\n</td></tr><tr><td>\r\nCount : </td><td>\r\n<select name=num>\r\n<option value=10>10</option>\r\n<option value=15>15</option>\r\n<option value=20>20</option>\r\n</select>\r\n</td></tr><tr><td colspan=2 align=center>\r\n<input type=submit value=''Listen''>\r\n</td></tr></table>\r\n</form>";\r\n', 5, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (34, 'New Songs', 'c', '<?\r\nglobal $action,$data,$data_singer,$data_comment,$lyrics_count,$urls_sets,$urls_data,$songs_fields_sets,$phrases;\r\n\r\n$qr_m=db_query("select *  from songs_new_songs_menu  order by ord asc");\r\n  $c = 0 ;\r\n\r\nif(db_num($qr_m)){\r\ncompile_template(get_template(''browse_songs_header''));\r\n\r\n$tr_ord = 1;\r\n\r\nwhile($data_m=db_fetch($qr_m)){\r\n$data = db_qr_fetch("select * from songs_songs where id=''$data_m[song_id]''");\r\n\r\n   $data_comment = db_qr_fetch("select * from songs_comments where id=''$data[comment]''"); \r\n\r\n        $data_singer = db_qr_fetch("select * from songs_singers where id=''$data[album]''");\r\n\r\n            if($tr_ord ==1){\r\n                   $tr_class="songs_1" ;\r\n                   $tr_ord = 2 ;\r\n                   }else{\r\n                    $tr_class="songs_2";\r\n                    $tr_ord = 1 ;\r\n                           }         \r\n      print "<tr class=''$tr_class''>";\r\n\r\n$urls_data = sync_urls_data($data[''id'']); \r\ncompile_template(get_template(''browse_songs''));\r\nprint "</tr>";\r\n        }\r\n\r\ncompile_template(get_template(''browse_songs_footer''));\r\n}else{\r\nprint "<center>$phrases[err_no_songs]</center>";\r\n}\r\n\r\n?>', 3, 1, 0, 'main,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (35, 'RSS', 'l', '<center><a href=''rss.php''><img src=''images/rss.gif'' border=0></a>\r\n<br>Singers Updates\r\n\r\n<br><br>\r\n\r\n<a href=''rss.php?op=songs''><img src=''images/rss.gif'' border=0></a>\r\n<br>Last Songs\r\n\r\n</center>', 8, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');
INSERT INTO `songs_blocks` (`id`, `title`, `pos`, `file`, `ord`, `active`, `template`, `pages`) VALUES (36, 'Playlists', 'l', '<?\r\nglobal $member_data,$phrases;\r\nif(check_member_login()){\r\n\r\nprint "\r\n<div id=\\"playlists_select_div\\">\r\n<script>\r\nget_playlists();\r\n</script>\r\n</div>\r\n<div id=\\"playlists_add_div\\" style=\\"display:none\\">\r\n<input type=text id=playlist_name name=playlist_name size=6>&nbsp;<input type=button value=\\"$phrases[add_button]\\" onclick=\\"playlists_submit($(''playlist_name'').value);\\"></div>";\r\n\r\n//----- List Items -----//\r\n\r\n$last_list_id = intval(get_cookie(''last_list_id''));\r\n\r\n\r\nprint "<form name=''playlist_form'' action=''songs_process.php'' method=''get''>\r\n<div id=\\"playlist_div\\" align=center style=\\"background-color:#FFFFFF;border: thin dashed #C0C0C0;\\">\r\n\r\n<script>\r\nget_playlist_items(".$last_list_id.");\r\n</script>";\r\n\r\nprint "</div><br>\r\n<center><input type=submit value=\\"$phrases[listen]\\"></center>\r\n</form>\r\n\r\n<script>\r\ninit_playlist_sortlist();\r\n</script>";\r\n\r\n}else{\r\nprint "<center> $phrases[please_login_first]</center>";\r\n}\r\n', 4, 1, 0, 'main,browse,songs,lyrics,browse_videos,news,pages,search,votes,statics,contactus,');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_cats`
-- 

CREATE TABLE `songs_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `download_limit` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `songs_cats`
-- 

INSERT INTO `songs_cats` (`id`, `name`, `ord`, `active`, `download_limit`) VALUES (7, 'Iraqi Songs', 4, 1, 0);
INSERT INTO `songs_cats` (`id`, `name`, `ord`, `active`, `download_limit`) VALUES (2, 'Gulf Songs', 2, 1, 0);
INSERT INTO `songs_cats` (`id`, `name`, `ord`, `active`, `download_limit`) VALUES (3, 'Egyptian Songs', 0, 1, 0);
INSERT INTO `songs_cats` (`id`, `name`, `ord`, `active`, `download_limit`) VALUES (4, 'Shami Songs', 1, 1, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_comments`
-- 

CREATE TABLE `songs_comments` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `songs_comments`
-- 

INSERT INTO `songs_comments` (`id`, `name`) VALUES (1, 'New');
INSERT INTO `songs_comments` (`id`, `name`) VALUES (2, 'Very New');
INSERT INTO `songs_comments` (`id`, `name`) VALUES (3, 'Music');
INSERT INTO `songs_comments` (`id`, `name`) VALUES (4, 'Remix');
INSERT INTO `songs_comments` (`id`, `name`) VALUES (6, 'Solo');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_confirmations`
-- 

CREATE TABLE `songs_confirmations` (
  `id` int(11) NOT NULL auto_increment,
  `type` text NOT NULL,
  `old_value` text NOT NULL,
  `new_value` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `code` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `songs_confirmations`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `songs_countries`
-- 

CREATE TABLE `songs_countries` (
  `name` varchar(80) NOT NULL default ''
) ;

-- 
-- Dumping data for table `songs_countries`
-- 

INSERT INTO `songs_countries` (`name`) VALUES ('Afghanistan');
INSERT INTO `songs_countries` (`name`) VALUES ('Albania');
INSERT INTO `songs_countries` (`name`) VALUES ('Algeria');
INSERT INTO `songs_countries` (`name`) VALUES ('American Samoa');
INSERT INTO `songs_countries` (`name`) VALUES ('Andorra');
INSERT INTO `songs_countries` (`name`) VALUES ('Angola');
INSERT INTO `songs_countries` (`name`) VALUES ('Anguilla');
INSERT INTO `songs_countries` (`name`) VALUES ('Antarctica');
INSERT INTO `songs_countries` (`name`) VALUES ('Antigua and Barbuda');
INSERT INTO `songs_countries` (`name`) VALUES ('Argentina');
INSERT INTO `songs_countries` (`name`) VALUES ('Armenia');
INSERT INTO `songs_countries` (`name`) VALUES ('Aruba');
INSERT INTO `songs_countries` (`name`) VALUES ('Australia');
INSERT INTO `songs_countries` (`name`) VALUES ('Austria');
INSERT INTO `songs_countries` (`name`) VALUES ('Azerbaijan');
INSERT INTO `songs_countries` (`name`) VALUES ('Bahamas');
INSERT INTO `songs_countries` (`name`) VALUES ('Bahrain');
INSERT INTO `songs_countries` (`name`) VALUES ('Bangladesh');
INSERT INTO `songs_countries` (`name`) VALUES ('Barbados');
INSERT INTO `songs_countries` (`name`) VALUES ('Belarus');
INSERT INTO `songs_countries` (`name`) VALUES ('Belgium');
INSERT INTO `songs_countries` (`name`) VALUES ('Belize');
INSERT INTO `songs_countries` (`name`) VALUES ('Benin');
INSERT INTO `songs_countries` (`name`) VALUES ('Bermuda');
INSERT INTO `songs_countries` (`name`) VALUES ('Bhutan');
INSERT INTO `songs_countries` (`name`) VALUES ('Bolivia');
INSERT INTO `songs_countries` (`name`) VALUES ('Bosnia and Herzegovina');
INSERT INTO `songs_countries` (`name`) VALUES ('Botswana');
INSERT INTO `songs_countries` (`name`) VALUES ('Bouvet Island');
INSERT INTO `songs_countries` (`name`) VALUES ('Brazil');
INSERT INTO `songs_countries` (`name`) VALUES ('British Indian Ocean Territory');
INSERT INTO `songs_countries` (`name`) VALUES ('Brunei Darussalam');
INSERT INTO `songs_countries` (`name`) VALUES ('Bulgaria');
INSERT INTO `songs_countries` (`name`) VALUES ('Burkina Faso');
INSERT INTO `songs_countries` (`name`) VALUES ('Burundi');
INSERT INTO `songs_countries` (`name`) VALUES ('Cambodia');
INSERT INTO `songs_countries` (`name`) VALUES ('Cameroon');
INSERT INTO `songs_countries` (`name`) VALUES ('Canada');
INSERT INTO `songs_countries` (`name`) VALUES ('Cape Verde');
INSERT INTO `songs_countries` (`name`) VALUES ('Cayman Islands');
INSERT INTO `songs_countries` (`name`) VALUES ('Central African Republic');
INSERT INTO `songs_countries` (`name`) VALUES ('Chad');
INSERT INTO `songs_countries` (`name`) VALUES ('Chile');
INSERT INTO `songs_countries` (`name`) VALUES ('China');
INSERT INTO `songs_countries` (`name`) VALUES ('Christmas Island');
INSERT INTO `songs_countries` (`name`) VALUES ('Cocos (Keeling) Islands');
INSERT INTO `songs_countries` (`name`) VALUES ('Colombia');
INSERT INTO `songs_countries` (`name`) VALUES ('Comoros');
INSERT INTO `songs_countries` (`name`) VALUES ('Congo');
INSERT INTO `songs_countries` (`name`) VALUES ('Cook Islands');
INSERT INTO `songs_countries` (`name`) VALUES ('Costa Rica');
INSERT INTO `songs_countries` (`name`) VALUES ('Cote D''Ivoire');
INSERT INTO `songs_countries` (`name`) VALUES ('Croatia');
INSERT INTO `songs_countries` (`name`) VALUES ('Cuba');
INSERT INTO `songs_countries` (`name`) VALUES ('Cyprus');
INSERT INTO `songs_countries` (`name`) VALUES ('Czech Republic');
INSERT INTO `songs_countries` (`name`) VALUES ('Denmark');
INSERT INTO `songs_countries` (`name`) VALUES ('Djibouti');
INSERT INTO `songs_countries` (`name`) VALUES ('Dominica');
INSERT INTO `songs_countries` (`name`) VALUES ('Dominican Republic');
INSERT INTO `songs_countries` (`name`) VALUES ('Ecuador');
INSERT INTO `songs_countries` (`name`) VALUES ('Egypt');
INSERT INTO `songs_countries` (`name`) VALUES ('El Salvador');
INSERT INTO `songs_countries` (`name`) VALUES ('Equatorial Guinea');
INSERT INTO `songs_countries` (`name`) VALUES ('Eritrea');
INSERT INTO `songs_countries` (`name`) VALUES ('Estonia');
INSERT INTO `songs_countries` (`name`) VALUES ('Ethiopia');
INSERT INTO `songs_countries` (`name`) VALUES ('Faroe Islands');
INSERT INTO `songs_countries` (`name`) VALUES ('Fiji');
INSERT INTO `songs_countries` (`name`) VALUES ('Finland');
INSERT INTO `songs_countries` (`name`) VALUES ('France');
INSERT INTO `songs_countries` (`name`) VALUES ('Gabon');
INSERT INTO `songs_countries` (`name`) VALUES ('Gambia');
INSERT INTO `songs_countries` (`name`) VALUES ('Georgia');
INSERT INTO `songs_countries` (`name`) VALUES ('Germany');
INSERT INTO `songs_countries` (`name`) VALUES ('Ghana');
INSERT INTO `songs_countries` (`name`) VALUES ('Gibraltar');
INSERT INTO `songs_countries` (`name`) VALUES ('Greece');
INSERT INTO `songs_countries` (`name`) VALUES ('Greenland');
INSERT INTO `songs_countries` (`name`) VALUES ('Grenada');
INSERT INTO `songs_countries` (`name`) VALUES ('Guadeloupe');
INSERT INTO `songs_countries` (`name`) VALUES ('Guam');
INSERT INTO `songs_countries` (`name`) VALUES ('Guatemala');
INSERT INTO `songs_countries` (`name`) VALUES ('Guinea');
INSERT INTO `songs_countries` (`name`) VALUES ('Guinea-Bissau');
INSERT INTO `songs_countries` (`name`) VALUES ('Guyana');
INSERT INTO `songs_countries` (`name`) VALUES ('Haiti');
INSERT INTO `songs_countries` (`name`) VALUES ('Honduras');
INSERT INTO `songs_countries` (`name`) VALUES ('Hong Kong');
INSERT INTO `songs_countries` (`name`) VALUES ('Hungary');
INSERT INTO `songs_countries` (`name`) VALUES ('Iceland');
INSERT INTO `songs_countries` (`name`) VALUES ('India');
INSERT INTO `songs_countries` (`name`) VALUES ('Indonesia');
INSERT INTO `songs_countries` (`name`) VALUES ('Iraq');
INSERT INTO `songs_countries` (`name`) VALUES ('Ireland');
INSERT INTO `songs_countries` (`name`) VALUES ('Israel');
INSERT INTO `songs_countries` (`name`) VALUES ('Italy');
INSERT INTO `songs_countries` (`name`) VALUES ('Jamaica');
INSERT INTO `songs_countries` (`name`) VALUES ('Japan');
INSERT INTO `songs_countries` (`name`) VALUES ('Jordan');
INSERT INTO `songs_countries` (`name`) VALUES ('Kazakhstan');
INSERT INTO `songs_countries` (`name`) VALUES ('Kenya');
INSERT INTO `songs_countries` (`name`) VALUES ('Kiribati');
INSERT INTO `songs_countries` (`name`) VALUES ('Korea, Republic of');
INSERT INTO `songs_countries` (`name`) VALUES ('Kuwait');
INSERT INTO `songs_countries` (`name`) VALUES ('Kyrgyzstan');
INSERT INTO `songs_countries` (`name`) VALUES ('Latvia');
INSERT INTO `songs_countries` (`name`) VALUES ('Lebanon');
INSERT INTO `songs_countries` (`name`) VALUES ('Lesotho');
INSERT INTO `songs_countries` (`name`) VALUES ('Liberia');
INSERT INTO `songs_countries` (`name`) VALUES ('Libyan Arab Jamahiriya');
INSERT INTO `songs_countries` (`name`) VALUES ('Liechtenstein');
INSERT INTO `songs_countries` (`name`) VALUES ('Lithuania');
INSERT INTO `songs_countries` (`name`) VALUES ('Luxembourg');
INSERT INTO `songs_countries` (`name`) VALUES ('Macao');
INSERT INTO `songs_countries` (`name`) VALUES ('Madagascar');
INSERT INTO `songs_countries` (`name`) VALUES ('Malawi');
INSERT INTO `songs_countries` (`name`) VALUES ('Malaysia');
INSERT INTO `songs_countries` (`name`) VALUES ('Maldives');
INSERT INTO `songs_countries` (`name`) VALUES ('Mali');
INSERT INTO `songs_countries` (`name`) VALUES ('Malta');
INSERT INTO `songs_countries` (`name`) VALUES ('Marshall Islands');
INSERT INTO `songs_countries` (`name`) VALUES ('Martinique');
INSERT INTO `songs_countries` (`name`) VALUES ('Mauritania');
INSERT INTO `songs_countries` (`name`) VALUES ('Mauritius');
INSERT INTO `songs_countries` (`name`) VALUES ('Mayotte');
INSERT INTO `songs_countries` (`name`) VALUES ('Mexico');
INSERT INTO `songs_countries` (`name`) VALUES ('Monaco');
INSERT INTO `songs_countries` (`name`) VALUES ('Mongolia');
INSERT INTO `songs_countries` (`name`) VALUES ('Montserrat');
INSERT INTO `songs_countries` (`name`) VALUES ('Morocco');
INSERT INTO `songs_countries` (`name`) VALUES ('Mozambique');
INSERT INTO `songs_countries` (`name`) VALUES ('Myanmar');
INSERT INTO `songs_countries` (`name`) VALUES ('Namibia');
INSERT INTO `songs_countries` (`name`) VALUES ('Nauru');
INSERT INTO `songs_countries` (`name`) VALUES ('Nepal');
INSERT INTO `songs_countries` (`name`) VALUES ('Netherlands');
INSERT INTO `songs_countries` (`name`) VALUES ('Netherlands Antilles');
INSERT INTO `songs_countries` (`name`) VALUES ('New Caledonia');
INSERT INTO `songs_countries` (`name`) VALUES ('New Zealand');
INSERT INTO `songs_countries` (`name`) VALUES ('Nicaragua');
INSERT INTO `songs_countries` (`name`) VALUES ('Niger');
INSERT INTO `songs_countries` (`name`) VALUES ('Nigeria');
INSERT INTO `songs_countries` (`name`) VALUES ('Niue');
INSERT INTO `songs_countries` (`name`) VALUES ('Norfolk Island');
INSERT INTO `songs_countries` (`name`) VALUES ('Norway');
INSERT INTO `songs_countries` (`name`) VALUES ('Oman');
INSERT INTO `songs_countries` (`name`) VALUES ('Pakistan');
INSERT INTO `songs_countries` (`name`) VALUES ('Palau');
INSERT INTO `songs_countries` (`name`) VALUES ('Panama');
INSERT INTO `songs_countries` (`name`) VALUES ('Papua New Guinea');
INSERT INTO `songs_countries` (`name`) VALUES ('Paraguay');
INSERT INTO `songs_countries` (`name`) VALUES ('Peru');
INSERT INTO `songs_countries` (`name`) VALUES ('Philippines');
INSERT INTO `songs_countries` (`name`) VALUES ('Pitcairn');
INSERT INTO `songs_countries` (`name`) VALUES ('Poland');
INSERT INTO `songs_countries` (`name`) VALUES ('Portugal');
INSERT INTO `songs_countries` (`name`) VALUES ('Puerto Rico');
INSERT INTO `songs_countries` (`name`) VALUES ('Qatar');
INSERT INTO `songs_countries` (`name`) VALUES ('Reunion');
INSERT INTO `songs_countries` (`name`) VALUES ('Romania');
INSERT INTO `songs_countries` (`name`) VALUES ('Russian Federation');
INSERT INTO `songs_countries` (`name`) VALUES ('Rwanda');
INSERT INTO `songs_countries` (`name`) VALUES ('Saint Helena');
INSERT INTO `songs_countries` (`name`) VALUES ('Saint Kitts and Nevis');
INSERT INTO `songs_countries` (`name`) VALUES ('Saint Lucia');
INSERT INTO `songs_countries` (`name`) VALUES ('Saint Pierre and Miquelon');
INSERT INTO `songs_countries` (`name`) VALUES ('Samoa');
INSERT INTO `songs_countries` (`name`) VALUES ('San Marino');
INSERT INTO `songs_countries` (`name`) VALUES ('Sao Tome and Principe');
INSERT INTO `songs_countries` (`name`) VALUES ('Saudi Arabia');
INSERT INTO `songs_countries` (`name`) VALUES ('Senegal');
INSERT INTO `songs_countries` (`name`) VALUES ('Serbia and Montenegro');
INSERT INTO `songs_countries` (`name`) VALUES ('Seychelles');
INSERT INTO `songs_countries` (`name`) VALUES ('Sierra Leone');
INSERT INTO `songs_countries` (`name`) VALUES ('Singapore');
INSERT INTO `songs_countries` (`name`) VALUES ('Slovakia');
INSERT INTO `songs_countries` (`name`) VALUES ('Slovenia');
INSERT INTO `songs_countries` (`name`) VALUES ('Solomon Islands');
INSERT INTO `songs_countries` (`name`) VALUES ('Somalia');
INSERT INTO `songs_countries` (`name`) VALUES ('South Africa');
INSERT INTO `songs_countries` (`name`) VALUES ('Spain');
INSERT INTO `songs_countries` (`name`) VALUES ('Sri Lanka');
INSERT INTO `songs_countries` (`name`) VALUES ('Sudan');
INSERT INTO `songs_countries` (`name`) VALUES ('Suriname');
INSERT INTO `songs_countries` (`name`) VALUES ('Svalbard and Jan Mayen');
INSERT INTO `songs_countries` (`name`) VALUES ('Swaziland');
INSERT INTO `songs_countries` (`name`) VALUES ('Sweden');
INSERT INTO `songs_countries` (`name`) VALUES ('Switzerland');
INSERT INTO `songs_countries` (`name`) VALUES ('Syrian Arab Republic');
INSERT INTO `songs_countries` (`name`) VALUES ('Taiwan, Province of China');
INSERT INTO `songs_countries` (`name`) VALUES ('Tajikistan');
INSERT INTO `songs_countries` (`name`) VALUES ('Thailand');
INSERT INTO `songs_countries` (`name`) VALUES ('Timor-Leste');
INSERT INTO `songs_countries` (`name`) VALUES ('Togo');
INSERT INTO `songs_countries` (`name`) VALUES ('Tokelau');
INSERT INTO `songs_countries` (`name`) VALUES ('Tonga');
INSERT INTO `songs_countries` (`name`) VALUES ('Trinidad and Tobago');
INSERT INTO `songs_countries` (`name`) VALUES ('Tunisia');
INSERT INTO `songs_countries` (`name`) VALUES ('Turkey');
INSERT INTO `songs_countries` (`name`) VALUES ('Turkmenistan');
INSERT INTO `songs_countries` (`name`) VALUES ('Turks and Caicos Islands');
INSERT INTO `songs_countries` (`name`) VALUES ('Tuvalu');
INSERT INTO `songs_countries` (`name`) VALUES ('Uganda');
INSERT INTO `songs_countries` (`name`) VALUES ('Ukraine');
INSERT INTO `songs_countries` (`name`) VALUES ('United Arab Emirates');
INSERT INTO `songs_countries` (`name`) VALUES ('United Kingdom');
INSERT INTO `songs_countries` (`name`) VALUES ('United States');
INSERT INTO `songs_countries` (`name`) VALUES ('Uruguay');
INSERT INTO `songs_countries` (`name`) VALUES ('Uzbekistan');
INSERT INTO `songs_countries` (`name`) VALUES ('Vanuatu');
INSERT INTO `songs_countries` (`name`) VALUES ('Venezuela');
INSERT INTO `songs_countries` (`name`) VALUES ('Viet Nam');
INSERT INTO `songs_countries` (`name`) VALUES ('Virgin Islands, British');
INSERT INTO `songs_countries` (`name`) VALUES ('Virgin Islands, U.s.');
INSERT INTO `songs_countries` (`name`) VALUES ('Wallis and Futuna');
INSERT INTO `songs_countries` (`name`) VALUES ('Western Sahara');
INSERT INTO `songs_countries` (`name`) VALUES ('Yemen');
INSERT INTO `songs_countries` (`name`) VALUES ('Zambia');
INSERT INTO `songs_countries` (`name`) VALUES ('Zimbabwe');
INSERT INTO `songs_countries` (`name`) VALUES ('Palestine');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_custom_fields`
-- 

CREATE TABLE `songs_custom_fields` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `song_id` int(11) NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `songs_custom_fields`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `songs_custom_sets`
-- 

CREATE TABLE `songs_custom_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `type` text NOT NULL,
  `value` text NOT NULL,
  `style` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `songs_custom_sets`
-- 

INSERT INTO `songs_custom_sets` (`id`, `name`, `type`, `value`, `style`, `ord`, `active`) VALUES (1, 'Poet', 'text', '', '', 0, 0);
INSERT INTO `songs_custom_sets` (`id`, `name`, `type`, `value`, `style`, `ord`, `active`) VALUES (2, 'Composer', 'text', '', '', 1, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_favorites`
-- 

CREATE TABLE `songs_favorites` (
  `id` int(11) NOT NULL auto_increment,
  `data_id` int(11) NOT NULL default '0',
  `type` text NOT NULL,
  `user` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `songs_favorites`
-- 

INSERT INTO `songs_favorites` (`id`, `data_id`, `type`, `user`) VALUES (2, 20, 'video', 1);
INSERT INTO `songs_favorites` (`id`, `data_id`, `type`, `user`) VALUES (3, 18, 'video', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_hooks`
-- 

CREATE TABLE `songs_hooks` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `hookid` text NOT NULL,
  `code` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `songs_hooks`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `songs_members`
-- 

CREATE TABLE `songs_members` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `active_code` text NOT NULL,
  `sex` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  `usr_group` int(11) NOT NULL default '0',
  `birth` date NOT NULL default '0000-00-00',
  `country` text NOT NULL,
  `mobile` text NOT NULL,
  `members_list` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `songs_members`
-- 

INSERT INTO `songs_members` (`id`, `username`, `password`, `email`, `active_code`, `sex`, `date`, `last_login`, `usr_group`, `birth`, `country`, `mobile`, `members_list`) VALUES (1, 'test', '098f6bcd4621d373cade4e832627b4f6', 'test@test.com', '', 'male', '2007-01-01 21:42:53', '2008-12-15 07:06:51', 1, '2007-01-01', 'Palestine', '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_members_fields`
-- 

CREATE TABLE `songs_members_fields` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `member` int(11) NOT NULL default '0',
  `value` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `songs_members_fields`
-- 

INSERT INTO `songs_members_fields` (`id`, `cat`, `member`, `value`) VALUES (3, 5, 1, '���\r');
INSERT INTO `songs_members_fields` (`id`, `cat`, `member`, `value`) VALUES (4, 6, 1, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_members_sets`
-- 

CREATE TABLE `songs_members_sets` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `details` text NOT NULL,
  `type` text NOT NULL,
  `value` text NOT NULL,
  `style` text NOT NULL,
  `required` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `songs_members_sets`
-- 

INSERT INTO `songs_members_sets` (`id`, `name`, `details`, `type`, `value`, `style`, `required`, `ord`) VALUES (5, 'Sex', '', 'select', 'Male\r\nFemale', '', 1, 0);
INSERT INTO `songs_members_sets` (`id`, `name`, `details`, `type`, `value`, `style`, `required`, `ord`) VALUES (6, 'Contact #', 'Tel or Mobile number', 'text', '', '', 0, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_msgs`
-- 

CREATE TABLE `songs_msgs` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `user` int(11) NOT NULL default '0',
  `sender` text NOT NULL,
  `opened` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `songs_msgs`
-- 

INSERT INTO `songs_msgs` (`id`, `title`, `content`, `user`, `sender`, `opened`, `date`) VALUES (1, 'Test', 'Test Test Test', 1, 'test', 1, '2008-12-11 04:30:41');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_news`
-- 

CREATE TABLE `songs_news` (
  `id` int(11) NOT NULL auto_increment,
  `writer` text NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `details` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `img` text NOT NULL,
  `timeout` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `songs_news`
-- 

INSERT INTO `songs_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`) VALUES (1, 'newsdesk', 'Keith Urban''s daughter obsessed with puppets', 'The 41-year-old actress has bought five-month-old Sunday Rose � her daughter with country musician husband Keith Urban � a turtle puppet toy for Christmas as she loves the make-believe characters.She said: ''This Christmas we will be celebrating with a lot of hugs and kisses and Christmas carols.', '\r\nThe 41-year-old actress has bought five-month-old Sunday Rose � her daughter with country musician husband Keith Urban � a turtle puppet toy for Christmas as she loves the make-believe characters.<BR /><BR />She said: ''This Christmas we will be celebrating with a lot of hugs and kisses and Christmas carols. We�ve bought her a turtle puppet � she loves puppets!''<BR /><BR />Nicole�s co-star in new movie ''Australia� Hugh Jackman added at the London premiere of the film last night (10.12.08) he is planning to spend the festive period in America rather than his native country Australia.<BR /><BR />The hunky star, who was recently named People magazine�s Sexiest Man Alive, revealed he wants to indulge in as many festive treats as possible, and is even looking forward to celebrating in colder weather.<BR /><BR />He said: ''I''m going to be in New York with my family. I''ll be going to the ''Nutcracker�, I''ll be going to Rockefeller Plaza, I''ll be going to the Rockettes, maybe catch a basketball game or two.<BR /><BR />''I''ve been at home for two years straight, so I''ll be OK. I actually like the snow. I like the cold � it''s all different, it''s all a novelty to me.'' ', '2008-12-15 05:44:06', 'uploads/news/keithurban.jpg', 0);
INSERT INTO `songs_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`) VALUES (2, 'newsdesk', 'Snoop Dogg Christmas album', 'Snoop Dogg Presents Christmas In Tha Dogg House will include exclusive festive songs from Snoop, Tha Dogg Pound, Soopafly, Bad Lucc, Damani, J. Black and The Hustle Boyz.You can preview the album, ''Xmas'' by Snoop Dogg featuring J.Black on the rapper''s MySpace page', '\r\nSnoop Dogg Presents Christmas In Tha Dogg House will include exclusive festive songs from Snoop, Tha Dogg Pound, Soopafly, Bad Lucc, Damani, J. Black and The Hustle Boyz.<BR /><BR />You can preview the album, ''Xmas'' by Snoop Dogg featuring J.Black on the rapper''s MySpace page <A href="http://www.myspace.com/snoopdogg">http://www.myspace.com/snoopdogg</A> <BR /><BR />Snoop Dogg Presents Christmas In Tha Dogg House will be available for digital download from 16 December.', '2008-12-15 05:47:11', 'uploads/news/snoop.jpg', 0);
INSERT INTO `songs_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`) VALUES (3, 'newsdesk', 'Jennifer Aniston to star next to her dog', 'The ''Marley and Me'' star says her beloved pet Norman would make a perfect film star because he has a wide variety of facial expressions and she already knows how the movie would look.She told MTV: &quot;I''d want to make a movie about Norman. If there was a way to put Norman in a movie I''d do it, b', '\r\nThe ''Marley and Me'' star says her beloved pet Norman would make a perfect film star because he has a wide variety of facial expressions and she already knows how the movie would look.<BR /><BR />She told MTV: "I''d want to make a movie about Norman. If there was a way to put Norman in a movie I''d do it, because his expressions are just perfect. <BR /><BR />"I want to do a short film called ''Cut to Norman'' and just have all these little vignettes, and then we could cut to Norman.<BR /><BR />"He''s a Corgi terrier/Australian shepherd. He''s a mutt. He''s great and adorable. He''s a human being in a dog suit."<BR /><BR />Jennifer - who reportedly spends $250 on therapists, massage and acupuncture for Norman - recently said she wished men were more like dogs.<BR /><BR />The actress, who is dating singer John Mayer, said: "It wouldn''t be bad if, when a man comes home, he''d run to his woman with his tail wagging. <BR /><BR />"This sort of excitement is something I''ve always missed in a man to be honest." ', '2008-12-15 05:48:00', 'uploads/news/jennifer-aniston.jpg', 0);
INSERT INTO `songs_news` (`id`, `writer`, `title`, `content`, `details`, `date`, `img`, `timeout`) VALUES (4, 'newsdesk', 'Avril Lavigne fires her manager', 'The ''Girlfriend� singer is said to be distraught that her latest album and tour proved less popular than her previous efforts, and blames Nettwerk mogul Terry McBride for her lack of success.A source told gossip blogger Perez Hilton: ''Avril is hoping that new management can help her new album be', '\r\nThe ''Girlfriend� singer is said to be distraught that her latest album and tour proved less popular than her previous efforts, and blames Nettwerk mogul Terry McBride for her lack of success.<BR /><BR />A source told gossip blogger Perez Hilton: ''Avril is hoping that new management can help her new album be more successful than the last.''<BR /><BR />The 24-year-old � who is desperate to resurrect her career - has reportedly now signed a new deal with Irving Azoff and his management company, who look after Christina Aguilera and Guns N'' Roses.<BR /><BR />Meanwhile, Avril has prompted rumours she is expecting her first child with musician husband Deryck Whibley after she was seen refusing alcohol during a recent night out.<BR /><BR />Avril � who recently sparked reports she could be pregnant after she was photographed with what appeared to be a baby bump - was spotted drinking only soft drinks at exclusive Hollywood night spot Coco De Ville.<BR /><BR />Avril, wearing a loose jersey shirt, stuck close to Deryck throughout the evening, with the pair making a hasty exit when other partygoers recognised her. ', '2008-12-15 05:48:41', 'uploads/news/avril.jpg', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_new_menu`
-- 

CREATE TABLE `songs_new_menu` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `type` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=33 ;

-- 
-- Dumping data for table `songs_new_menu`
-- 

INSERT INTO `songs_new_menu` (`id`, `cat`, `type`, `ord`) VALUES (31, 50, 'singer', 3);
INSERT INTO `songs_new_menu` (`id`, `cat`, `type`, `ord`) VALUES (29, 20, 'album', 0);
INSERT INTO `songs_new_menu` (`id`, `cat`, `type`, `ord`) VALUES (27, 24, 'album', 2);
INSERT INTO `songs_new_menu` (`id`, `cat`, `type`, `ord`) VALUES (30, 22, 'album', 4);
INSERT INTO `songs_new_menu` (`id`, `cat`, `type`, `ord`) VALUES (28, 53, 'singer', 1);
INSERT INTO `songs_new_menu` (`id`, `cat`, `type`, `ord`) VALUES (26, 23, 'album', 6);
INSERT INTO `songs_new_menu` (`id`, `cat`, `type`, `ord`) VALUES (32, 47, 'singer', 5);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_new_songs_menu`
-- 

CREATE TABLE `songs_new_songs_menu` (
  `id` int(11) NOT NULL auto_increment,
  `song_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `songs_new_songs_menu`
-- 

INSERT INTO `songs_new_songs_menu` (`id`, `song_id`, `ord`) VALUES (9, 114, 0);
INSERT INTO `songs_new_songs_menu` (`id`, `song_id`, `ord`) VALUES (10, 124, 0);
INSERT INTO `songs_new_songs_menu` (`id`, `song_id`, `ord`) VALUES (7, 135, 0);
INSERT INTO `songs_new_songs_menu` (`id`, `song_id`, `ord`) VALUES (6, 141, 0);
INSERT INTO `songs_new_songs_menu` (`id`, `song_id`, `ord`) VALUES (8, 127, 0);
INSERT INTO `songs_new_songs_menu` (`id`, `song_id`, `ord`) VALUES (11, 103, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_pages`
-- 

CREATE TABLE `songs_pages` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `songs_pages`
-- 

INSERT INTO `songs_pages` (`id`, `title`, `content`, `active`) VALUES (1, 'Test Page', '<HTML><HEAD><TITLE></TITLE></HEAD>\r\n<BODY>\r\n<DIV>This is test Page <BR><?\r\n\r\n\r\nprint "with PHP Code " ;\r\n?></DIV></BODY></HTML>', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_phrases`
-- 

CREATE TABLE `songs_phrases` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `value` text NOT NULL,
  `cat` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=548 ;

-- 
-- Dumping data for table `songs_phrases`
-- 

INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (1, 'the_songs', 'Songs', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (2, 'the_singers', 'Singers', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (3, 'the_songs_count', 'Songs Count', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (4, 'the_albums_count', 'Albums Count', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (5, 'last_update', 'Last Update', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (6, 'contact_us', 'Contact us', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (7, 'no_results', 'No Results', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (8, 'search_results', 'Search Results', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (9, 'download', 'Download', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (10, 'listen', 'Listen', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (11, 'vote_song', 'Vote Song', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (12, 'send2friend', 'Send to Friend', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (13, 'lyrics', 'Lyrics', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (14, 'watch', 'Watch', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (15, 'vote_video', 'Vote Video', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (16, 'err_no_page', 'Sorry , This page is not exists', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (17, 'type_search_keyword', 'Please type search keyword , Minimum {letters} Letters', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (18, 'the_name', 'Name', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (19, 'add_date', 'Add Date', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (20, 'err_no_videos', 'No Videos', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (21, 'err_wrong_url', 'Wrong URL', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (22, 'err_no_cats', 'No Categories', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (23, 'another_songs', 'Other Songs', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (24, 'pages', 'Pages', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (25, 'err_no_songs', 'No Songs', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (26, 'the_writer', 'Writer', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (27, 'the_news_archive', 'News Archive', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (28, 'vote_song_thnx_msg', 'Thank You , Song Vote Added', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (29, 'vote_video_thnx_msg', 'Thank You , Video Vote Added', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (30, 'vote_select', 'Vote', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (31, 'vote_do', 'Vote', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (32, 'send2friend_subject', 'Invitation from Your Friend', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (33, 'send2friend_done', 'Invitation sent to your Friend', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (34, 'your_name', 'Your Name', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (35, 'your_email', 'Your Email', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (36, 'your_friend_email', 'Friend Email', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (37, 'send', 'Send', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (38, 'err_vote_expire_hours', 'Sorry, You can vote Every {vote_expire_hours} Hour', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (39, 'add2favorite', 'Add to Favorite', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (40, 'add2fav_success', 'Added to Favorite Successfully', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (41, 'register_closed', 'Sorry , Registration is closed', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (42, 'no_news', 'No News', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (43, 'err_vote_file_expire_hours', 'Sorry , You can vote file every {vote_expire_hours} Hour', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (44, 'the_phrases', 'Phrases', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (45, 'welcome_to_cp', 'Welcome to Control Panel', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (46, 'php_version', 'PHP Version', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (47, 'mysql_version', 'MySQL Version', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (48, 'zend_version', 'Zend Optimizer Version', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (49, 'the_version', 'Version', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (50, 'cp_available', 'Available', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (51, 'cp_not_available', 'Not Available', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (52, 'gd_library', 'GD Library', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (53, 'gd_install_required', 'Gd library is not installed , without it script will not work fine.', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (54, 'cp_addons', 'Plugins', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (55, 'no_addons', 'No Plugins', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (56, 'edit', 'Edit', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (57, 'register', 'Register', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (58, 'register_email_exists', 'Email Already Exists', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (59, 'register_user_exists', 'Sorry , Username {username} Already Exists', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (60, 'reg_complete', 'Registration Complete Successfully', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (61, 'err_fileds_not_complete', 'Please Fill All Fields', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (62, 'err_passwords_not_match', 'Password is not match it', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (63, 'email', 'Email', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (64, 'username', 'Username', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (65, 'password', 'Password', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (66, 'cp_login_do', 'Login', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (67, 'cp_username', 'Username', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (68, 'cp_password', 'Password', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (69, 'the_content_type', 'Content Type', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (70, 'the_url', 'URL', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (71, 'bnr_appearance_places', 'Appearance Places', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (72, 'bnr_appearance_pages', 'Appearance Pages', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (73, 'add_after_menu_number', 'Add After Menu #', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (74, 'login_do', 'Login', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (75, 'bnr_ctype_code', 'Code', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (76, 'bnr_ctype_img', 'Image / URL', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (77, 'the_code', 'Code', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (78, 'bnr_open', 'Site-Open', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (79, 'bnr_close', 'Site-Close', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (80, 'bnr_menu', 'Menu', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (81, 'bnr_header', 'Header', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (82, 'bnr_footer', 'Footer', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (83, 'bnr_menu_pos', 'on', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (84, 'the_left', 'The Left', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (85, 'the_center', 'The Center', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (86, 'the_right', 'The Rigth', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (87, 'bnr_the_menu', 'The Menu', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (88, 'bnr_the_visits', 'Visits', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (89, 'bnr_appearance_count', 'Appearance Count', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (90, 'add_button', 'Add', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (91, 'the_order', 'Order', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (92, 'the_image', 'Picture', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (93, 'the_title', 'Title', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (94, 'delete', 'Delete', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (95, 'pages_lang', 'Pages Language', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (96, 'pages_encoding', 'Pages Encoding', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (97, 'cp_enable_browsing', 'Enable Browsing', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (98, 'cp_opened', 'Opened', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (99, 'cp_closed', 'Closed', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (100, 'cp_browsing_closing_msg', 'Browsing Close Message', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (101, 'site_closed_for_visitors', 'Website Closed For Visitors', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (102, 'cp_mailing_sending_to', 'Sending to', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (103, 'cp_send_as', 'Send As', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (104, 'cp_as_email', 'Email', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (105, 'next_page', 'Next Page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (106, 'failed', 'Failed', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (107, 'cp_as_pm', 'Personal Message', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (108, 'cp_send_to', 'Send To', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (109, 'all_members', 'All Members', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (110, 'one_member', 'One Member', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (111, 'sender_name', 'Sender Name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (112, 'sender_email', 'Sender Email', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (113, 'msg_type', 'Message Type', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (114, 'msg_encoding', 'Message Encoding', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (115, 'msg_subject', 'Message Subject', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (116, 'start_from', 'Start From', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (117, 'mailing_emails_perpage', 'Emails Per Page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (118, 'auto_pages_redirection', 'Auto Pages Redirection', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (119, 'cp_url_fopen_disabled_msg', 'your server settings does not allow you to import file from external url', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (120, 'err_url_x_invalid', 'Url : {url} is invalid', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (121, 'local_file_uploader', 'Local File', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (122, 'external_file_uploader', 'External File', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (123, 'cp_photo_resize_width', 'width', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (124, 'cp_photo_resize_hieght', 'hieght', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (125, 'view', 'View', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (126, 'members_mailing', 'Members Mailing', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (127, 'yes', 'Yes', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (128, 'no', 'No', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (129, 'cp_mng_members', 'Members Managment', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (130, 'members_custom_fields', 'Members Custom Fields', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (131, 'cp_members_remote_db', 'Remote Database', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (132, 'the_members', 'Members', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (133, 'cp_add_new_template', 'Add New Template', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (134, 'the_description', 'Description', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (135, 'cp_edit_templates', 'Edit Templates', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (136, 'main_page', 'Main Page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (137, 'the_templates', 'Templates', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (138, 'style_settings', 'Settings', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (139, 'add_style', 'Add new Styles', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (140, 'style_selectable', 'Selectable', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (141, 'template_name', 'Template Name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (142, 'template_description', 'Template Description', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (143, 'add_new_template', 'Add New Template', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (144, 'are_you_sure', 'Are You Sure ?', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (145, 'the_database', 'The Database', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (146, 'backup', 'Backup', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (147, 'db_repair_tables_do', 'Repair Tables', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (148, 'cp_db_backup_do', 'Do Backup now', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (149, 'the_file_path', 'File Path', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (150, 'db_backup_saveto_server', 'Save on Your website space', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (151, 'db_backup_saveto_pc', 'Save on Your Computer', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (152, 'cp_db_backup', 'Database Backup', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (153, 'the_size', 'Size', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (154, 'the_table', 'Table', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (155, 'the_status', 'Status', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (156, 'please_select_tables_to_rapair', 'Please Select tables that you want to repair', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (157, 'cp_repairing_table', 'Repairing ', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (158, 'done', 'Done', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (159, 'cp_db_check_repair', 'Check / Repair', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (160, 'backup_done_successfully', 'Backup Done Successfully', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (161, 'the_search', 'Search', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (162, 'members_count', 'Members', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (163, 'cp_remote_members_db', 'Remote Members Database', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (164, 'use_remote_db', 'Use Remote Database', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (165, 'db_host', 'Database Host', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (166, 'db_name', 'Database Name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (167, 'db_username', 'Database Username', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (168, 'members_table', 'Members Table Name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (169, 'note', 'Note', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (170, 'members_remote_db_wizzard_note', 'when you use a new members remote database you have to run Remote Database Wizzard to check if the database is compatible with script and setup it', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (171, 'members_remote_db_wizzard', 'Remote Database Wizard', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (172, 'chng_field_type_success', 'Field type changed successfully', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (173, 'chng_field_type_failed', 'unable to change field type , please change it manually from your database admin application', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (174, 'add_field_failed', 'unable to add field , please add it manually from your database admin application', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (175, 'add_field_success', 'Field added successfully', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (176, 'members_remote_db_compatible', 'Remote Database is compatible', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (177, 'members_remote_db_uncompatible', 'the database is not compatible with script, please check and correct the errors and run the wizzard again', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (178, 'wrong_remote_db_name', 'Wrong Remote Database name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (179, 'wrong_remote_db_connect_info', 'Error while connecting to remote database , please check connection info', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (180, 'members_remote_db_disabled', 'System is disabled', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (181, 'no_members_custom_fields', 'No Custom Fields', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (182, 'add_member_custom_field', 'Add New Field', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (183, 'the_type', 'Type', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (184, 'textbox', 'Text box', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (185, 'textarea', 'Text Area', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (186, 'select_menu', 'Select Menu', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (187, 'radio_button', 'Radio Button', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (188, 'checkbox', 'Checkbox', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (189, 'default_value_or_options', 'Default Value / Options', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (190, 'put_every_option_in_sep_line', 'For Options , put every option in new line', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (191, 'required', 'Required', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (192, 'addition_style', 'Field Style', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (193, 'addition_fields', 'Addition Fields', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (194, 'this_member_not_exists', 'This member is not exists', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (195, 'members_local_db_clean_wizzard', 'Local Database Clean Wizard', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (196, 'members_local_db_clean_note', 'When you use a remote or local database , some members data like private messages , favorites , custom fields , etc..  is stored on local database , so it', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (197, 'members_local_db_clean_description', 'Wizard will delete any members data as listed , please make sure that tables does not containing any important data then click on process button', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (198, 'members_msgs_table', 'Members Private Messages Table', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (199, 'members_favorite_table', 'Members Favorite files Table', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (200, 'members_custom_fields_table', 'Members Custom Fields Table', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (201, 'members_confirmations_table', 'Members Confirmations Table', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (202, 'process_done_successfully', 'Process Done Successfully', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (274, 'from', 'From', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (275, 'plz_enter_username_and_pwd', 'Please Enter the username and Password', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (204, 'pwd_rest_request_msg_subject', 'Rest Password Request', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (205, 'rest_pwd_request_msg_sent', 'changing password confirmation email sent to you', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (206, 'pwd_rest_done_msg_subject', 'Your New Password !', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (207, 'pwd_rest_done', 'Your password changed and sent to your email', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (208, 'security_code', 'Security Code', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (209, 'email_activation_msg_subject', 'Email Activation', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (210, 'upload_file', 'Upload File', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (211, 'search_do', 'Search', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (212, 'birth', 'Birth', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (213, 'country', 'Country', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (214, 'select_from_menu', 'Select From Menu', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (215, 'register_do', 'Register', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (216, 'registered_before', 'You are already registered', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (217, 'click_here', 'Click Here', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (218, 'forgot_pass', 'Forgot your Password?', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (219, 'login_info_sent', 'Login info sent to your email', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (220, 'email_not_exists', 'Sorry , This Email is not Exists', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (221, 'continue', 'Continue', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (222, 'active_account', 'Account Activation', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (223, 'active_acc_succ', 'Your Account Activated Successfullu', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (224, 'active_acc_err', 'Sorry , Wrong URL or Account Already Activated', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (225, 'login', 'Login', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (226, 'newuser', 'New Member ?', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (227, 'err_function_usage_denied', 'Error : You can', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (228, 'err_emails_not_match', 'Email is not matching it', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (229, 'email_confirm', 'Email Confirm', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (230, 'err_sec_code_not_valid', 'Security code is not valid', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (231, 'registration', 'Registration', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (232, 'as_every_cat_settings', 'as Every Category Settings', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (233, 'enabled_for_all', 'Enabled For All', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (234, 'stng_download_for_members_only', 'Downlaod For Members Only', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (235, 'security_code_in_registration', 'Registration Security Code', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (236, 'auto_email_activate', 'Auto Email Activation', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (237, 'username_min_letters', 'username Min Letters', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (238, 'username_exludes', 'username Excludes', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (239, 'emails_msgs_default_type', 'Emails Default Messages Type', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (240, 'emails_msgs_default_encoding', 'Emails Default Messages Encoding', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (241, 'leave_blank_to_use_site_encoding', 'leave it blank to use site encoding', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (242, 'uploader_system', 'Uploader System', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (243, 'disable_uploader_msg', 'Uploader Disable Message', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (244, 'uploader_path', 'Uploading Path', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (245, 'uploader_allowed_types', 'Allowed Types', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (246, 'enabled', 'Enabled', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (247, 'disabled', 'Disable', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (248, 'password_confirm', 'Password Confirm', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (249, 'err_username_min_letters', 'Error , username lenght is not meeting the minimum letters lenght', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (250, 'err_email_not_valid', 'invalid Email address', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (251, 'err_username_not_allowed', 'Username not allowed , please select another one', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (252, 'reg_complete_need_activation', 'Registration done , please check your email for activation message.', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (253, 'req_addition_info', 'Required Addition Info', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (254, 'not_req_addition_info', 'Not Required Addition Info', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (255, 'your_email_changed_successfully', 'Your Email Changed Successfully', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (256, 'this_account_already_activated', 'This Account Already Activated', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (257, 'closed_account_cannot_activate', 'Sorry, This is Closed Account , you can not Activate it', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (258, 'activation_msg_sent_successfully', 'Activation Message Sent Successfully', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (259, 'register_date', 'Registration Date', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (260, 'last_login', 'Last Login', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (261, 'member_deleted_successfully', 'Member Deleted successfully', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (262, 'member_added_successfully', 'Member Added Successfully', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (263, 'please_fill_all_fields', 'Please Fill All Fields', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (264, 'member_edited_successfully', 'Member edited successfully', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (265, 'add_member', 'Add Member', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (266, 'records_perpage', 'Records Per Page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (267, 'member_edit', 'Edit Member', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (268, 'member_acc_type', 'Account type', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (269, 'send_msg_to_member', 'Send Message to Member', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (270, 'acc_type_not_activated', 'Not Activated', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (271, 'acc_type_activated', 'Activated', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (272, 'acc_type_closed', 'Closed', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (273, 'leave_blank_for_no_change', 'Leave blank to not change', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (276, 'this_account_closed_cant_login', 'Sorrry , This Account is Closed', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (277, 'this_account_not_activated', 'Sorry , This account is not activated', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (278, 'chng_email_msg_subject', 'Changing email Confirm', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (279, 'resend_activation_msg', 'resend Activation Message', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (280, 'invalid_pwd', 'Sorry , Invalid Password', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (281, 'invalid_username', 'Sorry , Invalid Username', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (282, 'usercp_menu', 'Member Menu', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (283, 'usercp_welcome_msg', 'Welcome {username} to Member Control Panel', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (284, 'cp_hooks_fix_order', 'Fix Order', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (285, 'cp_hooks', 'Plugins / Hooks', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (286, 'no_hooks', 'No Hooks', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (287, 'add', 'Add', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (288, 'the_place', 'The Place', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (289, 'the_options', 'Options', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (290, 'the_default_template', 'Default Template', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (291, 'the_videos', 'Videos', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (292, 'the_news', 'News', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (293, 'the_votes', 'Votes', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (294, 'the_statics', 'Statics', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (295, 'appearance_places', 'Appearance Places', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (296, 'the_blocks', 'Blocks', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (297, 'the_position', 'Position', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (298, 'right', 'Right', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (299, 'center', 'Center', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (300, 'left', 'Left', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (301, 'the_template', 'Template', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (302, 'to_up', 'To up', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (303, 'to_down', 'To down', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (304, 'enable', 'Enable', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (305, 'disable', 'Disable', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (306, 'cp_blocks_fix_order', 'Fix Order', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (307, 'cp_no_blocks', 'No Blocks', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (308, 'the_content', 'Content', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (309, 'logout', 'Logout', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (310, 'the_settings', 'Settings', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (311, 'do_button', 'Process', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (312, 'news_add', 'Add News', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (313, 'news_short_content', 'Short Details', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (314, 'auto_short_content_create', 'Auto Short details Create', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (315, 'the_date', 'Date', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (316, 'all', 'All', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (317, 'view_do', 'View', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (318, 'os_and_browsers_statics', 'OS & Browsers Statics', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (319, 'visitors_hits_statics', 'Visitors Hits Statics', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (320, 'online_visitors_statics', 'Online Visitors Statics', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (321, 'default_style', 'Default Style', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (322, 'search_min_letters', 'Search Minimum Letters', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (323, 'sorry_search_disabled', 'Sorry , Search Disabled', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (324, 'uploader_title', 'Uploader', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (325, 'pixel', 'Pixel', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (326, 'this_filetype_not_allowed', 'File type not allowed', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (327, 'the_file', 'File', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (328, 'auto_photos_resize', 'Auto Pictures Resize', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (329, 'upload_file_do', 'Upload', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (330, 'allowed_filetypes', 'Allowed Types', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (331, 'please_login_first', 'Please Login First', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (332, 'uploader_thumb_width', 'Uploader - Thumb Max Width', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (333, 'uploader_thumb_hieght', 'Uploader - Thumb Max Hieght', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (334, 'fixed', 'Fixed', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (335, 'send2friend_failed', 'Error whie sending , please try again later', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (336, 'invalid_from_or_to_email', 'Invalid From or To Email Address', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (337, 'bnr_listen', 'Listen File', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (338, 'urls_fields', 'Songs Urls Fields', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (339, 'urls_fields_add', 'Add new Field', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (340, 'access_denied', 'Access Denied', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (341, 'no_singers', 'No Singers', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (342, 'the_cat', 'Category', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (343, 'singers_list', 'Singers List', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (344, 'singer', 'Singer', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (345, 'album', 'Album', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (346, 'the_albums', 'Albums', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (347, 'no_new_files', 'No New Files', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (348, 'err_autosearch_folder_not_exists', 'Error, Auto Search folder is invalid', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (349, 'auto_search', 'Auto Search', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (350, 'add_songs', 'Add Songs', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (351, 'new_songs_menu', 'New Songs Menu', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (352, 'new_stores_menu', 'New Stores Menu', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (353, 'the_banners', 'Banners', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (354, 'users_and_permissions', 'Users & Permissions', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (355, 'permissions_manage', 'Permissions Manage', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (356, 'cp_sections_permissions', 'Sections Permissions', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (357, 'videos_cats_permissions', 'Videos Categories', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (358, 'songs_cats_permissions', 'Songs Categories', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (359, 'cp_err_username_exists', 'Error , Username already Exists', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (360, 'cp_plz_enter_usr_pwd', 'Please Enter username and password', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (361, 'cp_edit_user_success', 'Edit User Done Successfully', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (362, 'cp_add_user', 'Add User', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (363, 'cp_email', 'Email', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (364, 'cp_user_group', 'Group', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (365, 'cp_user_admin', 'Administrator', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (366, 'cp_user_mod', 'Moderator', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (367, 'the_users', 'Users', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (368, 'edit_personal_acc_only', 'Sorry , You can only edit your account info', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (369, 'click_here_to_edit_ur_account', 'To edit your account click here', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (372, 'the_pages', 'Pages', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (373, 'pages_add', 'Add New Page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (374, 'no_pages', 'No Pages', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (375, 'err_cat_access_denied', 'Category Access Denied', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (376, 'songs_custom_fields', 'Custom Fields', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (377, 'songs_field_add', 'Add New Field', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (378, 'no_data', 'No Data', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (381, 'songs_default_orderby', 'Songs Default Sort', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (380, 'field_style', 'Field Style', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (382, 'asc', 'ASC', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (383, 'desc', 'DESC', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (384, 'visitors_can_sort_songs', 'Visitors Can Select Songs Sort', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (386, 'the_most_voted', 'Most Voted', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (387, 'songs_orderby_text', 'Order By', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (388, 'the_download', 'Download', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (389, 'download_for_all_visitors', 'All Visitors Can Download', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (390, 'download_for_members_only', 'Members Only Can Downlaod', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (391, 'stng_videos_download_for_members_only', 'Only Members Can Download Videos', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (392, 'add_to_playlist', 'Add to Playlist', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (393, 'stng_songs_multi_select', 'Enable multi-select songs for visitors', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (394, 'playlists_add', 'Add New Playlist', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (395, 'playlists_del', 'Delete Current Playlist', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (396, 'printable_copy', 'Print', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (397, 'members_playlists_table', 'Playlists Table', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (398, 'singers_other_letters', 'Other', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (399, 'the_favorite', 'Favorite', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (400, 'no_files', 'No Files', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (401, 'send_new_msg', 'Send New Message', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (402, 'the_messages', 'Messages', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (403, 'used_messages', 'Used Messages', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (404, 'pm_box_full_warning', 'Warning : Your Box is Full and you can', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (405, 'no_messages', 'No Messages', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (406, 'the_sender', 'Sender', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (407, 'the_subject', 'Subject', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (408, 'reply', 'Reply', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (409, 'err_sendto_pm_box_full', 'Error, Box that you trying to sent to is full.', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (410, 'pm_sent_successfully', 'Your Message Sent Successfully', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (411, 'err_sendto_username_invalid', 'Error , Receiver username is invalid', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (412, 'the_message', 'Message', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (413, 'chng_email_conf_msg_sent', 'your new email confirmation message sent to your email', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (414, 'your_profile_updated_successfully', 'Your Profile Updated Successfully', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (415, 'the_profile', 'Profile', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (416, 'default_playlist', 'Default Playlist', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (417, 'err_wrong_uploader_folder', 'Wrong Uploader Folder', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (418, 'register_email_exists2', 'if this is your email and you forgot the password ', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (419, 'the_statics_and_counters', 'Statics & Counters', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (420, 'cp_visitors_statics', 'Visitors Statics', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (421, 'cp_counters_start_date', 'Counters start Date', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (422, 'cp_total_visits', 'Total Visits', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (423, 'the_hour', 'Hour', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (424, 'operating_systems', 'Operating Systems', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (425, 'the_browsers', 'Browser', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (426, 'monthly_statics_for', 'Monthly Statics for ', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (427, 'daily_statics_for', 'Daily Statics for', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (428, 'the_year', 'Year', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (429, 'the_month', 'Month', 'main');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (430, 'right_to_left', 'Right to Left', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (431, 'left_to_right', 'Left to Right', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (432, 'page_dir', 'Page Direction', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (433, 'mailing_email', 'Mailing Email', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (434, 'copyrights_sitename', 'Copyrights Site Name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (435, 'section_name', 'Section Name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (436, 'site_name', 'Site Name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (437, 'page_keywords', 'Keywords', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (438, 'votes_expire_time', 'Seperation time between votes', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (439, 'hour', 'Hour', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (440, 'the_songs_cats', 'Songs Categories', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (441, 'the_songs_and_singers', 'Singers & Songs', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (442, 'the_songs_comments', 'Songs Comments', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (443, 'add_edit_videos', 'Add / Edit Videos', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (444, 'bnr_views', 'View', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (445, 'bnr_visits', 'Visit', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (446, 'del_cat_warning', 'Warning : This Action will delete also all songs and singers under this category , Continue ?', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (447, 'show_download_icon', 'Show download icon', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (448, 'the_download_icon', 'Download Icon', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (449, 'download_icon_alt', 'Download icon Alt', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (450, 'show_listen_icon', 'Show Listen Icon', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (451, 'the_listen_icon', 'Listen Icon', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (452, 'listen_icon_alt', 'Listen icon Alt', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (453, 'listen_file_mime', 'Listen File MIME', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (454, 'listen_file_name', 'Listen File Name', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (455, 'listen_file_content', 'Listen FIle Content', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (456, 'the_cats', 'Categories', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (457, 'del_video_cat_warning', 'Warning : This Action will delete also all videos under this category , Continue ?', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (458, 'add_video', 'Add New Video', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (459, 'add_cat', 'Add Category', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (460, 'no_videos_or_no_permissions', 'No Video or you do not have the permissions to see this category', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (461, 'default', 'Default', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (462, 'view_page', 'View Page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (463, 'vote_add', 'Add new Vote', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (464, 'set_default', 'Set as Default', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (465, 'edit_or_options', 'Edit / Options', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (466, 'add_options', 'Add Options', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (467, 'vote_files_expire_time', 'Seperation time between files votes', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (468, 'images_cells_count', 'Images Cells Count', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (469, 'news_perpage', 'News Per Page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (470, 'back_to_cats', 'Back to Categories', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (471, 'singer_add', 'Add Singer', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (472, 'no_singers_or_no_permissions', 'No Singer or you do not have the permissions to see this category', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (473, 'move_songs', 'Move Songs', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (474, 'move_from', 'Move From', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (475, 'move_to', 'Move to', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (476, 'please_select_songs_first', 'Please Select Songs Firts', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (477, 'next', 'Next', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (478, 'without_album', 'Without Album', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (479, 'the_album', 'Album', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (480, 'move_do', 'Move', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (481, 'back_to_singers', 'Back to Singers', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (482, 'edit_singer', 'Edit Singer', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (483, 'del_singer_warning', 'Warning  : This Action will delete also all songs and albums under this singer , Continue ?', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (484, 'song', 'Song', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (485, 'select_all', 'Check All', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (486, 'select_none', 'Uncheck All', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (487, 'change_comment', 'Change Comment', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (488, 'move_to_album', 'Move to Album', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (489, 'move_to_singer', 'Move to Singer', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (490, 'edit_songs', 'Edit Songs', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (491, 'delete_songs', 'Delete Songs', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (492, 'add_to_new_songs_menu', 'Add to New Songs Menu', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (493, 'without_comment', 'Without Comment', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (494, 'the_comment', 'Comment', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (495, 'fields_count', 'Fields Count', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (496, 'edit_album', 'Edit Album', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (497, 'singers_count', 'Singers Count', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (498, 'songs_count', 'Songs Count', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (499, 'videos_count', 'Videos Count', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (500, 'users_count', 'Users', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (501, 'show_sitename_in_subpages', 'Show Site name in sub-pages', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (502, 'show_section_name_in_subpages', 'Show Section name in sub-pages', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (503, 'adding_songs_fields_count', 'Fields Count in Adding Songs Page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (504, 'songs_perpage', 'Songs per-page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (505, 'videos_perpage', 'Videos per-page', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (506, 'msgs_count_limit', 'Member Messages Limit', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (507, 'message', 'Message', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (508, 'stng_singers_letters', 'Singers Letters Bar', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (509, 'stng_songs_letters', 'Songs Letters Bar', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (510, 'stng_vote_songs', 'Voting Songs', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (511, 'stng_send_song', 'Sending songs to friends', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (512, 'stng_group_singers_by_letters', 'Show Singer in Letters Groups', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (513, 'stng_vote_videos', 'Voting Videos', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (514, 'stng_send_videos', 'Sending Videos to friends', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (515, 'the_listen_file', 'Listen File', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (516, 'ram_banner_width', 'Banners window width', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (517, 'ram_banner_height', 'Banners window height', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (518, 'listen_statics_rest_done', 'Rest Songs Listens Done', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (519, 'download_statics_rest_done', 'Rest Songs Downloads Done', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (520, 'votes_statics_rest_done', 'Rest Songs Votes Done', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (521, 'videos_watch_rest_done', 'Rest Videos Views Done', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (522, 'videos_download_rest_done', 'Rest Videos Downloads Done', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (523, 'videos_votes_rest_done', 'Rest Videos Votes Done', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (524, 'songs_listens_statics', 'Songs Listens', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (525, 'songs_downloads_statics', 'Songs Downloads', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (526, 'songs_votes_statics', 'Songs Votes', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (527, 'videos_watch_statics', 'Videos Views', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (528, 'videos_download_statics', 'Videos Downloads', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (529, 'videos_votes_statics', 'Videos Votes', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (530, 'err_invalid_song_id', '<b>Error : </b> Invalid Song ID', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (531, 'song_id', 'Song ID', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (532, 'err_invalid_id', '<b>Error : </b> Invalid ID', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (533, 'the_id', 'ID', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (534, 'without_title', 'No Title', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (535, 'cp_rest_counters', 'Rest Counters', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (536, 'cp_rest_counters_do', 'Rest Counters', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (537, 'visitors_statics_rest_done', 'Rest Counters Done', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (538, 'cp_no_phrases', 'No Phrases', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (539, 'cp_no_templates', 'No Templates', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (540, 'cp_invalid_pwd', 'invalid password', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (541, 'cp_invalid_username', 'invalid username', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (542, 'cp_welcome_msg', 'Welcome {username}', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (543, 'cp_statics', 'Statics', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (544, 'search', 'Search', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (545, 'forgot_pwd_msg_subject', 'Recover your password', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (546, 'without_selection', 'None', 'cp');
INSERT INTO `songs_phrases` (`id`, `name`, `value`, `cat`) VALUES (547, 'create_main_user', 'Create Main User', 'cp');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_phrases_cats`
-- 

CREATE TABLE `songs_phrases_cats` (
  `id` text NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY  (`id`(20))
) ;

-- 
-- Dumping data for table `songs_phrases_cats`
-- 

INSERT INTO `songs_phrases_cats` (`id`, `name`) VALUES ('main', 'General');
INSERT INTO `songs_phrases_cats` (`id`, `name`) VALUES ('cp', 'Control Panel / System');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_playlists`
-- 

CREATE TABLE `songs_playlists` (
  `id` int(11) NOT NULL auto_increment,
  `member_id` int(11) NOT NULL default '0',
  `name` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `songs_playlists`
-- 

INSERT INTO `songs_playlists` (`id`, `member_id`, `name`) VALUES (8, 1, 'My Playlist');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_playlists_data`
-- 

CREATE TABLE `songs_playlists_data` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `song_id` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `member_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=53 ;

-- 
-- Dumping data for table `songs_playlists_data`
-- 

INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (42, 7, 55, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (41, 7, 51, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (50, 8, 115, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (49, 8, 113, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (43, 7, 50, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (44, 7, 51, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (45, 0, 52, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (47, 0, 51, 3, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (48, 0, 50, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (51, 8, 114, 0, 1);
INSERT INTO `songs_playlists_data` (`id`, `cat`, `song_id`, `ord`, `member_id`) VALUES (52, 8, 139, 0, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_ramadv`
-- 

CREATE TABLE `songs_ramadv` (
  `content` text NOT NULL,
  `height` int(11) NOT NULL default '0',
  `width` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0'
) ;

-- 
-- Dumping data for table `songs_ramadv`
-- 

INSERT INTO `songs_ramadv` (`content`, `height`, `width`, `active`) VALUES ('<html dir=rtl>\r\n<center><img src=''http://allomani.biz/allomani_banner.gif''>\r\n<br>\r\n<?\r\nprint $_SERVER[''SERVER_NAME'']; \r\n?>\r\n</center>\r\n</html>', 200, 600, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_settings`
-- 

CREATE TABLE `songs_settings` (
  `name` text NOT NULL,
  `value` text NOT NULL
) ;

-- 
-- Dumping data for table `songs_settings`
-- 

INSERT INTO `songs_settings` (`name`, `value`) VALUES ('snd2friend', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('vote_song', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('sitename', 'Allomani');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('section_name', 'Songs & Clips v2.7.0');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('songs_add_fields', '5');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('letters_songs', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('letters_singers', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('html_dir', 'ltr');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('header_keywords', 'Songs , Videos ');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('uploader', '0');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('uploader_path', 'uploads');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('uploader_msg', 'Sorry , This Function is disabled in Demo Version');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('uploader_types', 'jpg,gif,png,rm,mp3');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('songs_add_limit', '10');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('singers_groups', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('songs_perpage', '30');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('songs_cells', '4');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('vote_clip', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('snd2friend_clip', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('votes_expire_hours', '24');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('copyrights_sitename', 'Allomani');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('search_min_letters', '3');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('msgs_count_limit', '30');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('mailing_email', 'mailing@allomani.biz');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('member_download_only', '2');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('members_register', '0');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('news_perpage', '10');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('vote_file_expire_hours', '24');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('site_pages_lang', 'en-us');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('site_pages_encoding', 'windows-1252');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('enable_browsing', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('disable_browsing_msg', '<center>Sorry , Site Closed Temporary</center>');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('register_sec_code', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('auto_email_activate', '0');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('register_username_exclude_list', 'admin,mod,webmaster');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('register_username_min_letters', '4');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('mailing_default_use_html', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('mailing_default_encoding', '');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('count_visitors_info', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('count_visitors_hits', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('count_online_visitors', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('enable_search', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('default_styleid', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('uploader_thumb_width', '100');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('uploader_thumb_hieght', '100');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('ramadv_width', '600');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('ramadv_height', '200');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('sitename_in_subpages', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('section_name_in_subpages', '0');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('videos_perpage', '20');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('visitors_can_sort_songs', '1');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('songs_default_orderby', 'name');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('songs_default_sort', 'asc');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('videos_member_download_only', '2');
INSERT INTO `songs_settings` (`name`, `value`) VALUES ('songs_multi_select', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_singers`
-- 

CREATE TABLE `songs_singers` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` text NOT NULL,
  `img` text NOT NULL,
  `last_update` datetime NOT NULL default '0000-00-00 00:00:00',
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=54 ;

-- 
-- Dumping data for table `songs_singers`
-- 

INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (16, 7, 'Majed Al Mohandes', 'thumbs/majid-almohandis.gif', '2006-11-10 22:58:29', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (1, 4, 'Elissa', 'thumbs/elissa.gif', '2006-08-24 14:11:15', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (24, 3, 'Tamer Hosny', 'thumbs/tamer.gif', '2006-04-24 22:16:38', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (10, 2, 'Rashed El Majed', '', '0000-00-00 00:00:00', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (13, 4, 'Ragheb Alama', 'thumbs/ragheb.gif', '0000-00-00 00:00:00', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (5, 4, 'Rayan', 'thumbs/rayan.gif', '2006-04-24 07:17:27', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (21, 3, 'Shadi Aswad', 'thumbs/shadi-aswad.gif', '0000-00-00 00:00:00', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (17, 3, 'Amr Diab', '', '0000-00-00 00:00:00', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (12, 4, 'Assi El Hellany', 'uploads/singers/assi-el7ellani.gif', '2008-12-13 06:01:40', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (15, 7, 'Kazem Al Saher', 'thumbs/kazim.gif', '0000-00-00 00:00:00', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (43, 4, 'Fares Karam', 'thumbs/faris-karram.gif', '0000-00-00 00:00:00', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (47, 4, 'Sara El Hani', 'uploads/singers/sara-alhani.gif', '2008-12-11 05:14:08', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (48, 7, 'Adel Mokhtar', 'uploads/singers/adel-mo5tar.gif', '2008-12-13 05:40:28', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (49, 4, 'Samo Zean', 'uploads/singers/samo-zean.gif', '2008-12-13 05:51:59', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (50, 4, 'Layal', 'uploads/singers/layal.gif', '2008-12-13 06:06:21', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (51, 3, 'Jawaher', 'uploads/singers/jawaher.gif', '2008-12-13 06:10:23', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (52, 3, 'Rami Sabry', 'uploads/singers/rami-sabry.gif', '2008-12-13 06:26:57', 1);
INSERT INTO `songs_singers` (`id`, `cat`, `name`, `img`, `last_update`, `active`) VALUES (53, 3, 'Tamer Ashour', 'uploads/singers/tamer-3ashour.gif', '2008-12-13 06:28:53', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_songs`
-- 

CREATE TABLE `songs_songs` (
  `id` int(11) NOT NULL auto_increment,
  `album` int(11) NOT NULL default '0',
  `album_id` int(11) NOT NULL default '0',
  `name` text NOT NULL,
  `url` text NOT NULL,
  `lyrics` text NOT NULL,
  `downloads` int(11) NOT NULL default '0',
  `listens` int(11) NOT NULL default '0',
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `comment` int(11) NOT NULL default '0',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=142 ;

-- 
-- Dumping data for table `songs_songs`
-- 

INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (37, 5, 4, 'Hekyo Einayk', 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Hekyo-Eyneyk.rm', '', 0, 0, '2006-04-24 07:17:27', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (36, 5, 4, 'Kanet Rohi', 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Kanet-Rohi.rm', '', 0, 0, '2006-04-24 07:17:27', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (35, 5, 4, 'Meen Ghayrak', 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Min-Ghayrak.rm', '', 0, 0, '2006-04-24 07:17:27', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (34, 5, 4, 'Haram Alayk', 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Haram-Eleyk.rm', '', 20, 2, '2006-04-24 07:17:27', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (33, 5, 4, 'Alby Ehtar', 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Albi-Ehtar.rm', '', 1, 2, '2006-04-24 07:17:27', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (32, 1, 16, 'Bastanak', 'http://song4.6arab.com/ELISSA_Bastanak.rm', '', 23, 2, '2006-04-24 07:17:27', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (31, 1, 16, 'Ta''a', 'http://www.mazikana.com/Songs/E/Elissa/rm/Bastnak/Mazikana_Elissa---Taa.rm', '', 8, 0, '2006-04-24 07:17:27', 1, 5, 1);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (30, 1, 16, 'Kermalak', 'http://www.mazikana.com/Songs/E/Elissa/rm/Bastnak/Mazikana_Elissa---Kermalak.rm', '', 9, 0, '2006-04-24 07:17:27', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (29, 1, 16, 'Fatet Senin', 'http://www.mazikana.com/Songs/E/Elissa/rm/Bastnak/Mazikana_Elissa---Fatet-Senen.rm', '', 0, 0, '2006-04-24 07:17:27', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (28, 1, 16, 'Ba''esh Ala Hessak', 'http://www.mazikana.com/Songs/E/Elissa/rm/Bastnak/Mazikana_Elissa---Baaesh-Ala-Hessak.rm', '', 9, 2, '2006-04-24 07:17:27', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (50, 24, 0, 'Etla''a Men Dol', 'http://song4.6arab.com/Tamer-7osny_etl3-mn-dol.rm', 'Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here ', 9, 0, '2006-04-24 20:52:31', 1, 3, 1);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (51, 24, 0, 'El Waheeda', 'http://song4.6arab.com/Tamer-7osny_elwa7eda.rm', '', 0, 0, '2006-04-24 20:52:31', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (52, 24, 0, 'Ana Wala Aref', 'http://song4.6arab.com/tamer_7osney_ana-wala-3aref.rm', 'Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here Lyrics Here ', 0, 0, '2006-04-24 20:52:31', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (55, 24, 0, 'Ana Wala Aref', 'http://song4.6arab.com/tamer_7osney_ana-wala-3aref.rm', '', 1, 4, '2006-04-24 22:16:38', 2, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (71, 12, 0, 'Samedoon', 'http://song.6arab.com/3ady_samedoon.rm', '', 1, 2, '2006-08-24 14:05:59', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (72, 1, 0, 'Ayshalak', 'http://songs1.6arab.com/elissa..3ayshalak.rm', '', 1, 5, '2006-08-24 14:11:15', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (78, 16, 18, 'Enjannet', 'http://song5.6arab.com/maged-al-mohandes_enganait.rm', '', 1, 1, '2006-11-10 22:58:29', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (79, 16, 18, 'Ben Eidaya', 'http://song5.6arab.com/maged-al-mohandes_bain-edaya.rm', '', 0, 0, '2006-11-10 22:58:29', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (80, 16, 18, 'Ganna Ganna', 'http://song5.6arab.com/maged-al-mohandes_ganna-ganna.rm', '', 0, 0, '2006-11-10 22:58:29', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (81, 16, 18, 'Kel Laila', 'http://song5.6arab.com/maged-al-mohandes_kel-laila.rm', '', 0, 0, '2006-11-10 22:58:29', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (82, 16, 18, 'Male''tsh Ela Ana', 'http://song5.6arab.com/maged-al-mohandes_mala2etsh-ella-ana.rm', '', 0, 0, '2006-11-10 22:58:29', 1, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (99, 47, 0, 'Elly Nasiny', '', '', 0, 0, '2008-12-11 05:14:08', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (98, 47, 0, 'Eftkrtk', '', '', 0, 0, '2008-12-11 05:14:08', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (100, 47, 0, 'Fdeet Rohak', '', '', 0, 0, '2008-12-11 05:14:08', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (101, 47, 0, 'Sho A''a Balo', '', '', 0, 0, '2008-12-11 05:14:08', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (102, 47, 0, 'Olt Eh', '', '', 0, 0, '2008-12-11 05:14:08', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (103, 47, 0, 'Law Khayaroni', '', '', 0, 0, '2008-12-11 05:14:08', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (104, 47, 0, 'Ma Hada Byebedny Annak', '', '', 0, 0, '2008-12-11 05:14:08', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (105, 47, 0, 'Hek Bte''amol', '', '', 0, 0, '2008-12-11 05:14:08', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (106, 48, 0, 'Oumi', '', '', 0, 0, '2008-12-13 05:40:28', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (107, 48, 0, 'Ana Wayak', '', '', 0, 0, '2008-12-13 05:40:28', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (108, 48, 0, 'T''hen Li', '', '', 0, 0, '2008-12-13 05:40:28', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (109, 48, 0, 'Rohi Fe Roh', '', '', 0, 0, '2008-12-13 05:40:28', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (110, 48, 0, 'Sghira', '', '', 0, 0, '2008-12-13 05:40:28', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (111, 49, 20, 'Ehsas Beyshdny', '', '', 0, 0, '2008-12-13 05:45:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (112, 49, 20, 'Getlak Beteak', '', '', 0, 0, '2008-12-13 05:45:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (113, 49, 20, 'Khatem fe Eidy', '', '', 0, 0, '2008-12-13 05:45:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (114, 49, 20, 'Tale''a Le Min', '', '', 0, 0, '2008-12-13 05:45:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (115, 49, 20, 'Aref Maly', '', '', 0, 0, '2008-12-13 05:45:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (116, 49, 20, 'Leek Lewahdk', '', '', 0, 0, '2008-12-13 05:45:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (117, 49, 21, 'Aref Leh', '', '', 0, 0, '2008-12-13 05:51:59', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (118, 49, 21, 'Ayam w Snin', '', '', 0, 0, '2008-12-13 05:51:59', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (119, 49, 21, 'Bahlam Beek', '', '', 0, 0, '2008-12-13 05:51:59', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (120, 49, 21, 'Elly Ma benna', '', '', 0, 0, '2008-12-13 05:51:59', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (121, 12, 22, 'El Hawa Zalem', '', '', 0, 0, '2008-12-13 06:01:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (122, 12, 22, 'Bandah Ma Byesma''a', '', '', 0, 0, '2008-12-13 06:01:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (123, 12, 22, 'Boset Khanjer', '', '', 0, 0, '2008-12-13 06:01:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (124, 12, 22, 'Halet Alby', '', '', 0, 0, '2008-12-13 06:01:40', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (125, 50, 0, 'Aboya Ally', '', '', 0, 0, '2008-12-13 06:06:21', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (126, 50, 0, 'Tshoby', '', '', 0, 0, '2008-12-13 06:06:21', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (127, 50, 0, 'Hawassi Kella', '', '', 0, 0, '2008-12-13 06:06:21', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (128, 50, 0, 'Am Behlamak', '', '', 0, 0, '2008-12-13 06:06:21', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (129, 51, 23, 'Andy', '', '', 0, 0, '2008-12-13 06:10:23', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (130, 51, 23, 'Bet''ol Eh', '', '', 0, 0, '2008-12-13 06:10:23', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (131, 51, 23, 'Khamsa w Khmisa', '', '', 0, 0, '2008-12-13 06:10:23', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (132, 51, 23, 'Sog Ya Sawwag', '', '', 0, 0, '2008-12-13 06:10:23', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (133, 52, 24, 'El Kalam Kollo', '', '', 0, 0, '2008-12-13 06:26:57', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (134, 52, 24, 'Ghamadt Einy', '', '', 0, 0, '2008-12-13 06:26:57', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (135, 52, 24, 'Kelma', '', '', 0, 0, '2008-12-13 06:26:57', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (136, 52, 24, 'Mabalash', '', '', 0, 0, '2008-12-13 06:26:57', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (137, 53, 0, 'Eftara''na', '', '', 0, 0, '2008-12-13 06:28:53', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (138, 53, 0, 'Enta Meen Yesedak', '', '', 0, 0, '2008-12-13 06:28:53', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (139, 53, 0, 'Teslm', '', '', 0, 0, '2008-12-13 06:28:53', 0, 5, 1);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (140, 53, 0, 'Zy Kol Marra', '', '', 0, 0, '2008-12-13 06:28:53', 0, 0, 0);
INSERT INTO `songs_songs` (`id`, `album`, `album_id`, `name`, `url`, `lyrics`, `downloads`, `listens`, `date`, `comment`, `votes`, `votes_total`) VALUES (141, 53, 0, 'Kattar khiri', '', '', 0, 0, '2008-12-13 06:28:53', 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_templates`
-- 

CREATE TABLE `songs_templates` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `protected` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=64 ;

-- 
-- Dumping data for table `songs_templates`
-- 

INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (1, 'Site Header', 'header', '<BODY onunload="pop_close()"  bgColor=#ffffff\r\nleftMargin=0 topMargin=0>\r\n        \r\n        \r\n<table id="Table_01" width="100%" border="0" cellpadding="0" cellspacing="0" dir=ltr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/songs270_01.gif" width="27" height="350" alt=""></td>\r\n		<td>\r\n			<img src="images/songs270_02.gif" width="151" height="350" alt=""></td>\r\n		<td background="images/songs270_03.gif" width="100%" height="350" >\r\n			</td>\r\n		<td>\r\n			<img src="images/songs270_04.gif" width="560" height="350" alt=""></td>\r\n		<td>\r\n			<img src="images/songs270_03-05.gif" width="27" height="350" alt=""></td>\r\n	</tr>\r\n	</table>\r\n<table width=100%  border="0" cellpadding="0" cellspacing="0">\r\n<tr>\r\n		<td background="images/songs270_06.gif" width="27">\r\n<img src="images/songs270_06.gif" width="27"> \r\n			</td>\r\n		<td width=100%>\r\n<br>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (58, '', 'links_browse_songs', 'singer-{id}.html', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (59, '', 'links_browse_songs_w_album', 'album-{id}-{album_id}.html', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (2, 'Site Footer', 'footer', '<br>\r\n<div align=left>&nbsp;&nbsp;&nbsp;\r\n<?global $styleid;print_style_selection();?>\r\n</div><br>\r\n\r\n</td>\r\n				<td background="images/songs270_10.gif" width="27">\r\n<img src="images/songs270_10.gif" width="27">\r\n		</td>\r\n	</tr>\r\n</table>\r\n<table width=100%  border="0" cellpadding="0" cellspacing="0">\r\n	<tr>\r\n		<td>\r\n			<img src="images/songs270_11.gif" width="27" height="63" alt=""></td>\r\n		<td>\r\n			<img src="images/songs270_12.gif" width="151" height="63" alt=""></td>\r\n		<td background="images/songs270_13.gif" width="100%" height="63" >\r\n		</td>\r\n		<td>\r\n			<img src="images/songs270_14.gif" width="560" height="63" alt=""></td>\r\n		<td>\r\n			<img src="images/songs270_15.gif" width="27" height="63" alt=""></td>\r\n	</tr>\r\n</table>\r\n\r\n</body>\r\n</html>        \r\n        \r\n        ', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (3, 'Blocks', 'block', '<table id="Table_01" width="100%" border="0" cellpadding="0" cellspacing="0" dir=ltr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/menu_01.gif" width="22" height="56" alt=""></td>\r\n		<td>\r\n			<img src="images/menu_02.gif" width="10" height="56" alt=""></td>\r\n		<td  background="images/menu_03.gif" width="100%" height="56">\r\n			&nbsp;</td>\r\n		<td>\r\n			<img src="images/menu_04.gif" width="17" height="56" alt=""></td>\r\n		<td>\r\n			<img src="images/menu_03-05.gif" width="33" height="56" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td background="images/menu_06.gif" width="22">\r\n			</td>\r\n		<td colspan="3">\r\n		{title}{new_line}{content}</td>\r\n		<td background="images/menu_08.gif" width="33">\r\n			</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/menu_07-09.gif" width="22" height="43" alt=""></td>\r\n		<td>\r\n			<img src="images/menu_10.gif" width="10" height="43" alt=""></td>\r\n		<td background="images/menu_11.gif" width="100%" height="43">\r\n		</td>\r\n		<td>\r\n			<img src="images/menu_12.gif" width="17" height="43" alt=""></td>\r\n		<td>\r\n			<img src="images/menu_13.gif" width="33" height="43" alt=""></td>\r\n	</tr>\r\n</table>\r\n', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (4, 'Tables', 'table', '<table id="Table_01" width="100%" border="0" cellpadding="0" cellspacing="0" dir=ltr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/menu_01.gif" width="22" height="56" alt=""></td>\r\n		<td>\r\n			<img src="images/menu_02.gif" width="10" height="56" alt=""></td>\r\n		<td  background="images/menu_03.gif" width="100%" height="56">\r\n			&nbsp;</td>\r\n		<td>\r\n			<img src="images/menu_04.gif" width="17" height="56" alt=""></td>\r\n		<td>\r\n			<img src="images/menu_03-05.gif" width="33" height="56" alt=""></td>\r\n	</tr>\r\n	<tr>\r\n		<td background="images/menu_06.gif" width="22">\r\n			</td>\r\n		<td colspan="3">\r\n		{title}{new_line}{content}</td>\r\n		<td background="images/menu_08.gif" width="33">\r\n			</td>\r\n	</tr>\r\n	<tr>\r\n		<td>\r\n			<img src="images/menu_07-09.gif" width="22" height="43" alt=""></td>\r\n		<td>\r\n			<img src="images/menu_10.gif" width="10" height="43" alt=""></td>\r\n		<td background="images/menu_11.gif" width="100%" height="43">\r\n		</td>\r\n		<td>\r\n			<img src="images/menu_12.gif" width="17" height="43" alt=""></td>\r\n		<td>\r\n			<img src="images/menu_13.gif" width="33" height="43" alt=""></td>\r\n	</tr>\r\n</table>\r\n', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (5, 'Contact us', 'contactus', '<center>You can change this text from templates in control panel</center>\r\n        ', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (6, 'Send Song to Friend Message', 'friend_msg', '<html>\r\n<body>\r\n\r\n<div>\r\n\r\n<p>Your Friend Sent this Song to You </p>\r\n\r\nYour Friend Name: {name_from}<br>\r\nYour Friend Email : {email_from}<br><br>\r\n\r\nSong Name : {title} <br><br>\r\n\r\nTo Listen : <br> {url_listen} \r\n\r\n<br>\r\n\r\nTo Download : <br> {url_download}\r\n</div>\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n\r\n</body>\r\n</html>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (7, 'Sending Video to Friend Message', 'friend_msg_clip', '<html>\r\n<body>\r\n\r\n<div>\r\n\r\n\r\n<p>Your Friend sent a video to you</p>\r\n\r\nYour Friend Name : {name_from}<br>\r\nYour Friend Email : {email_from}<br><br>\r\n\r\nVideo Title : {title} <br><br>\r\n\r\nView : <br> {url_watch}\r\n<br>\r\nDownload  : <br> {url_download}\r\n\r\n</div>\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n\r\n</body>\r\n</html>\r\n\r\n        \r\n        \r\n        \r\n        ', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (47, 'Email Activation Message', 'email_activation_msg', '<html>\r\n<body>\r\n\r\nDear {name}, <br><br>\r\n\r\n\r\nTo Activate your Email Address Please open the Following Link : <br>\r\n\r\n{url} \r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>\r\n', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (8, 'Java Script Functions', 'js_functions', '<script>\r\n\r\nfunction banner_pop_open(url,name){\r\nmsgwindow=window.open(url,name,"toolbar=yes,scrollbars=yes,resizable=yes,width=650,height=300,top=200,left=200");\r\n}\r\n\r\nfunction banner_pop_close(url,name){\r\nmsgwindow=window.open(url,name,"toolbar=yes,scrollbars=yes,resizable=yes,width=650,height=300,top=200,left=200");\r\n}\r\n\r\n\r\nfunction snd(id)\r\n{\r\nmsgwindow=window.open("send2friend.php?id="+id,"displaywindow","toolbar=no,scrollbars=no,width=400,height=320,top=200,left=200")\r\n}\r\n\r\nfunction snd_vid(id)\r\n{\r\n\r\nmsgwindow=window.open("send2friend.php?op=video&id="+id,"displaywindow","toolbar=no,scrollbars=no,width=400,height=320,top=200,left=200")\r\n}\r\n\r\nfunction vote_song(id,action)\r\n{\r\n\r\nmsgwindow=window.open("vote_song.php?id="+id+"&action="+action,"displaywindow","toolbar=no,scrollbars=no,width=350,height=250,top=200,left=200")\r\n}\r\n\r\nfunction add2fav(id,type)\r\n{\r\nmsgwindow=window.open("add2fav.php?id="+id+"&type="+type,"displaywindow","toolbar=no,scrollbars=no,width=350,height=150,top=200,left=200")\r\n}\r\n\r\n\r\nfunction CheckAll(form_id)\r\n{\r\n\r\ncount = document.getElementById(form_id).elements.length;\r\n    for (i=0; i < count; i++) \r\n	{\r\n    if((document.getElementById(form_id).elements[i].checked == 1) ||(document.getElementById(form_id).elements[i].checked == 0))\r\n    	{document.getElementById(form_id).elements[i].checked = 1; }\r\n  \r\n	}\r\n}\r\nfunction UncheckAll(form_id){\r\ncount = document.getElementById(form_id).elements.length;\r\n    for (i=0; i < count; i++) \r\n	{\r\n    if((document.getElementById(form_id).elements[i].checked == 1) || (document.getElementById(form_id).elements[i].checked == 0))\r\n    	{document.getElementById(form_id).elements[i].checked = 0; }\r\n\r\n	}\r\n}\r\n</script>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (11, 'Singers Letters Bar', 'letters_singers', '<p align="center" class="title">\r\n<a class="big" href="index.php?action=browse&op=letter&letter=A">A</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=B">B</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=C">C</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=D">D</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=E">E</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=F">F</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=G">G</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=H">H</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=I">I</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=J">J</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=K">K</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=L">L</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=M">M</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=N">N</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=O">O</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=P">P</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=Q">Q</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=R">R</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=S">S</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=T">T</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=U">U</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=V">V</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=W">W</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=X">X</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=Y">Y</a>\r\n<a class="big" href="index.php?action=browse&op=letter&letter=Z">Z</a>\r\n</p> ', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (12, 'Songs Letters Bar', 'letters_songs', '<p align="center" class="title">\r\n<a class="big" href="index.php?action=songs&op=letter&letter=A">A</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=B">B</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=C">C</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=D">D</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=E">E</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=F">F</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=G">G</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=H">H</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=I">I</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=J">J</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=K">K</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=L">L</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=M">M</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=N">N</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=O">O</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=P">P</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=Q">Q</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=R">R</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=S">S</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=T">T</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=U">U</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=V">V</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=W">W</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=X">X</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=Y">Y</a>\r\n<a class="big" href="index.php?action=songs&op=letter&letter=Z">Z</a>\r\n</p>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (13, 'Show Singers ', 'browse_singers', '<?\r\nglobal $data,$data_cat,$action;\r\nprint "<center><a href=''".get_template(''links_browse_songs'',''{id}'',$data[''id''])."''><img border=0 src=''".get_image($data[''img''])."''><br>$data[name]</a><br>";\r\n\r\nif(!$action){\r\nprint "<font color=#9D9D9D>".substr($data[''last_update''],0,10)."</font>";\r\n}\r\n\r\nif($action=="search"){\r\nprint "<a href=''".get_template(''links_browse_cat'',''{id}'',$data_cat[''id''])."''>$data_cat[name]</a></center>";\r\n}\r\n\r\nprint "</center>";\r\n?>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (14, 'Show Albums', 'browse_albums', '<?\r\nglobal $phrases,$data,$album_songs_num,$data_singer,$action;\r\n\r\nprint "<center><a href=''".get_template(''links_browse_songs_w_album'',array(''{id}'',''{album_id}''),array($data_singer[''id''],$data[''id'']))."''><img border=0 src=''".get_image($data[''img''])."'' alt=\\"$phrases[the_songs_count]: $album_songs_num\\"><br>";\r\nif(!$action){\r\nprint "$data_singer[name] - ";\r\n}\r\nprint "$data[name]</a></center>";\r\n?>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (51, '', 'links_song_listen', 'song_listen_{id}_{cat}', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (52, '', 'links_song_download', 'song_download_{id}_{cat}', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (20, 'Show Videos', 'browse_videos', '<?\r\nglobal $data,$data_cat,$settings,$phrases,$action,$is_user_cp;\r\n\r\nprint " <td><center><a href=''".get_template(''links_video_watch'',''{id}'',$data[''id''])."''>\r\n            <img border=0 alt=''$phrases[the_name] : $data[name] \\n$phrases[add_date] : ".substr($data[''date''],0,10)."''\r\n            src=''".get_image($data[''img''])."''>\r\n            <br>$data[name] </a><br>\r\n\r\n<a href=''".get_template(''links_video_download'',''{id}'',$data[''id''])."''><img src=''images/download.gif'' border=0 alt=''$phrases[download]''></a>\r\n<a href=''".get_template(''links_video_watch'',''{id}'',$data[''id''])."''><img src=''images/watch.gif'' border=0 alt=''$phrases[watch]''></a>";\r\n\r\nif($settings[''snd2friend_clip'']){\r\nprint "<a href=''javascript:snd_vid($data[id])''><img src=''images/send.gif'' border=0 alt=''$phrases[send2friend]''></a>";\r\n}\r\n\r\nif($settings[''vote_clip'']){\r\nprint "<a href=\\"javascript:vote_song(''$data[id]'',''video'')\\"><img src=''images/vote_video.gif'' alt=''$phrases[vote_video]'' border=0></a>";\r\n}\r\n\r\n if(check_member_login() && !$is_user_cp){\r\n          print "<a href=\\"javascript:add2fav($data[id],''video'');\\"><img src=''images/favorite_small.gif'' alt=''$phrases[add2favorite]'' border=0></a>";\r\n          }\r\n\r\nif($action==''search''){\r\nprint "<br><a href=''index.php?action=browse_videos&cat=$data_cat[id]''>$data_cat[name]</a>";\r\n}\r\n\r\n print "</center>    </td>";\r\n        ?>\r\n        \r\n        \r\n        \r\n        ', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (22, 'News - outside', 'browse_news', '<?\r\nglobal $phrases,$data;\r\n$news_date = date("d-m-Y",strtotime($data[''date'']));\r\nprint "<table width=100%><tr><td width=20%><img src=''".get_image($data[''img''])."''></td>\r\n<td><center><font color=''#808080'' class=''title''>$data[title]</font></center><br>\r\n<font color=''#808080''>$news_date : </font> $data[content] ... <a href=''".get_template(''links_browse_news'',''{id}'',$data[''id''])."''> More </a>\r\n<br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font></td></tr></table>";\r\n?>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (18, 'Show Songs', 'browse_songs', '<?\r\nglobal $data,$data_comment,$data_singer,$op,$settings,$phrases,$lyrics_count,$action,$is_user_cp,$urls_sets,$urls_data,$songs_fields_sets;\r\n\r\n\r\nprint "\r\n<td>";\r\nif($settings[''songs_multi_select'']){\r\nprint "<input type=''checkbox'' name=\\"song_id[]\\" value=\\"$data[id]\\">";\r\n}\r\nprint "<img src=''images/song.gif'' border=0> &nbsp; $data[name]";\r\n\r\nif($data_comment[''name'']){\r\nprint "&nbsp;&nbsp;  <i><font color=#D20000>$data_comment[name]</font></i>";\r\n}\r\n\r\n$br_printed = false;\r\nfor($i=0;$i<count($songs_fields_sets);$i++){\r\n$field_data = get_song_field_value($songs_fields_sets[$i][''id''],$data[''id'']);\r\n\r\nif($field_data){\r\nif(!$br_printed){print "<br>";$br_printed=true;}\r\nprint "<b>".$songs_fields_sets[$i][''name'']." : </b>". $field_data ."&nbsp";\r\n}\r\n\r\n}\r\n\r\nprint "</td>";\r\n\r\nif((!$action || $action==''search'') || $op==''letter''  || $is_user_cp){\r\nprint "<td><a href=''".get_template(''links_browse_songs'',''{id}'',$data_singer[''id''])."''>$data_singer[name]</a></td>";\r\n}\r\n\r\nfor($i=0;$i<count($urls_sets);$i++){\r\n\r\nif($urls_sets[$i][''show_listen'']){\r\nif($urls_data[$urls_sets[$i][''id'']][''url'']){\r\nprint "<td align=center width=5%><a href=''".get_template(''links_song_listen'',array(''{cat}'',''{id}''),array($urls_sets[$i][''id''],$data[''id'']))."''><img src=''".get_image($urls_sets[$i][''listen_icon''],''images/listen.gif'')."'' alt=''".str_replace("{listens}",$urls_data[$urls_sets[$i][''id'']][''listens''],$urls_sets[$i][''listen_alt''])."'' border=0></a></td>";\r\n}else{\r\nprint "<td></td>";\r\n}\r\n}\r\nif($urls_sets[$i][''show_download'']){\r\nif($urls_data[$urls_sets[$i][''id'']][''url'']){\r\n print "<td align=center width=5%><a href=''".get_template(''links_song_download'',array(''{cat}'',''{id}''),array($urls_sets[$i][''id''],$data[''id'']))."''><img src=''".get_image($urls_sets[$i][''download_icon''],''images/save.gif'')."'' alt=''".str_replace("{downloads}",$urls_data[$urls_sets[$i][''id'']][''downloads''],$urls_sets[$i][''download_alt''])."'' border=0></a></td>";\r\n}else{\r\nprint "<td></td>";\r\n}\r\n}\r\n}\r\nif($settings[''vote_song'']){\r\n print "<td align=center width=5%><a href=\\"javascript:vote_song(''$data[id]'',''song'')\\"><img src=''images/vote_song.gif'' alt=''$phrases[vote_song]'' border=0></a></td>    ";\r\n         \r\n}\r\n\r\nif($settings[''snd2friend'']){\r\n          print "<td align=center width=5%><a href=\\"javascript:snd($data[id])\\"><img src=''images/snd.gif'' alt=''$phrases[send2friend]'' border=0></a></td>    ";\r\n         }\r\n\r\n          if(check_member_login() && !$is_user_cp){\r\n          print "<td align=center width=5%><a href=\\"javascript:playlist_add_song($data[id]);\\"><img src=''images/playlist_add.gif'' alt=''$phrases[add_to_playlist]'' border=0></a></td>";\r\n          }\r\n\r\nif($data[''lyrics'']){\r\nprint" <td align=center width=5%><a href=''lyrics-$data[id].html''><img src=''images/lyric.gif'' alt=''$phrases[lyrics]'' border=0></a></td>";\r\n}else{\r\nif($lyrics_count > 0){\r\nprint "<td width=5%></td>";\r\n}\r\n}\r\n\r\n\r\n\r\n?>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (42, 'Fonts &amp; Colors Template', 'CSS', '/*------------ BODY ---------------*/\r\n\r\nFONT {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n	}\r\nTD {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\nBODY {\r\nFONT-SIZE: 8pt; COLOR: #1266a5 ; FONT-FAMILY: Tahoma; \r\nSCROLLBAR-FACE-COLOR: #ffffff; SCROLLBAR-SHADOW-COLOR: #277eb3; \r\nSCROLLBAR-3DLIGHT-COLOR: #ffffff; SCROLLBAR-ARROW-COLOR: #277eb3; \r\nSCROLLBAR-TRACK-COLOR: #ffffff; SCROLLBAR-DARKSHADOW-COLOR: #ffffff; \r\nBACKGROUND-COLOR: #ffffff; \r\naSCROLLBAR-HIGHLIGHT-COLOR: #ffffff\r\n\r\n	}\r\nP {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n	}\r\nDIV {\r\nFONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*---------- TITLES FONT --------------*/\r\n.title {\r\n	FONT-SIZE: 10pt; BACKGROUND: ; COLOR: #458A00; FONT-FAMILY: Tahoma; TEXT-DECORATION: none; font-weight:bold\r\n}\r\n\r\n\r\n/*------------- LINKS ---------------*/\r\nA:link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n\r\nA:active {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n\r\n}\r\nA:visited {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:hover {\r\n	FONT-SIZE: 8pt; COLOR: #007CF9; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n/*---------- LETTERS LINKS -----------*/\r\nA:link.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n\r\nA:active.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n\r\n}\r\nA:visited.big {\r\n	FONT-SIZE: 10pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:hover.big {\r\n	FONT-SIZE: 10pt; COLOR: #007CF9; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n/*----------- PATH BAR LINKS ------------*/\r\nA:link.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:active.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n\r\n}\r\nA:visited.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #0066CC; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\nA:hover.path_link {\r\n	FONT-SIZE: 8pt; COLOR: #007CF9; FONT-FAMILY: Tahoma; TEXT-DECORATION: none\r\n}\r\n\r\n\r\n/*---------- SONGS TABLES COLORS ---------*/\r\n.songs_1{\r\nbackground-color: #f7f7f7\r\n}\r\n.songs_2{\r\nbackground-color: #FCFCFC \r\n}\r\n\r\n/*--------- MEMBERS MESSAGES FONT--------*/\r\n.messages {\r\n	FONT-SIZE: 8pt; FONT-FAMILY: Tahoma; \r\n}\r\n\r\n/*------------ SPARATE LINKE -----------------*/\r\n.separate_line{\r\ncolor: #D7DDFD;border-width: 1px\r\n}\r\n/*------------ Search Replace-----------------*/\r\n.search_replace{\r\ncolor: #FF0000;\r\n}', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (23, 'Pages Head', 'page_head', '<?global $settings;\r\nglobal $section_name,$title_sub,$sitename,$meta_keywords,$meta_description,$settings,$action;\r\n\r\n$default_desciption   = $settings[''header_keywords''];\r\n\r\nif(($section_name && $settings[''section_name_in_subpages'']) || $title_sub){\r\n$full_title = iif($sitename && ($settings[''sitename_in_subpages''] || !$action),$sitename,'''');\r\n}else{\r\n$full_title = $sitename;\r\n}\r\nif($section_name && ($settings[''section_name_in_subpages''] || !$action)){\r\n$full_title .= iif($full_title," - $section_name",$section_name);\r\n}\r\n\r\nif($title_sub){\r\n$full_title .= iif($full_title," - $title_sub",$title_sub);\r\n}\r\n\r\n\r\nprint "<html dir=\\"$settings[html_dir]\\">\r\n<head>\r\n";\r\nprint "<!-- no cache headers -->\r\n	<meta http-equiv=\\"Pragma\\" content=\\"no-cache\\" />\r\n	<meta http-equiv=\\"Expires\\" content=\\"-1\\" />\r\n	<meta http-equiv=\\"Cache-Control\\" content=\\"no-cache\\" />\r\n<!-- end no cache headers -->\r\n<meta http-equiv=\\"Content-Type\\" content=\\"text/html; charset=$settings[site_pages_encoding]\\" \r\n\r\n/>\r\n <meta name=\\"generator\\" content=\\"Allomani Audio and Video v2.7\\" />\r\n<meta name=\\"keywords\\" content=\\"allomani,allomani.biz,&#1575;&#1604;&#1604;&#1608;&#1605;&#1575;&#1606;&#1610;,".iif($settings\r\n\r\n[header_keywords],$settings[header_keywords].",","").$meta_keywords."\\" />\r\n \r\n<meta name=\\"description\\" content=\\"$default_desciption $meta_description\\" />\r\n\r\n<meta name=\\"abstract\\" content=\\"$default_desciption $meta_description\\" />\r\n\r\n<meta name=\\"robots\\" content=\\"index, follow\\" />\r\n<meta name=\\"rating\\" content=\\"General\\" /> \r\n<meta name=\\"distribution\\" content=\\"Global\\" />\r\n\r\n<meta http-equiv=\\"Content-Language\\" content=\\"$settings[site_pages_lang]\\" />\r\n\r\n\r\n\r\n\r\n<LINK href=\\"css.php\\" type=text/css rel=StyleSheet>";\r\n\r\nprint "<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Singers\\" href=\\"rss.php\\">";\r\nprint "<link rel=\\"alternate\\" type=\\"application/rss+xml\\" title=\\"RSS - Songs\\" href=\\"rss.php?\r\n\r\nop=songs\\">\r\n<title>$full_title</title>";\r\n\r\n?>\r\n<script type="text/javascript" src="js/prototype.js"></script>\r\n<script type="text/javascript" src="js/ajax.js"></script>\r\n<script type="text/javascript" src="js/scriptaculous/scriptaculous.js"></script>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (43, 'News - Inside', 'browse_news_inside', '<?\r\nglobal $data,$phrases;\r\n\r\n$news_date = date("d-m-Y",strtotime($data[''date'']));\r\n\r\nprint "<table width=100%><tr><td>\r\n\r\n<DIV style=\\"FLOAT: right\\"><TABLE border=\\"0\\"><TBODY><TR><TD><TABLE border=\\"0\\"><TBODY><TR><TD align=\\"center\\">\r\n<img src=''".get_image($data[''img''])."''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>$news_date</font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV  align=\\"left\\">\r\n$data[details] <br><br> $phrases[the_writer] : <font color=''#808080''>$data[writer]</font>\r\n\r\n</td></tr>\r\n<tr><td colspan=2 align=right><a href=''news_print.php?id=$data[id]''><img src=''images/print.gif'' alt=''$phrases[printable_copy]'' border=0></a>\r\n\r\n</div>\r\n\r\n</td></tr></table>";\r\n?>\r\n        \r\n        ', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (44, 'News - Print', 'browse_news_print', '<html>\r\n<title>{title}</title>\r\n\r\n<table width=100%>\r\n<tr>\r\n<td>\r\n<p align=center><font size=5><b>{title}</b></font></p>\r\n</td></tr>\r\n\r\n<tr><td>\r\n\r\n<DIV style="FLOAT: right"><TABLE border="0"><TBODY><TR><TD><TABLE border="0"><TBODY><TR><TD align="center">\r\n<img src=''{img}''>\r\n</TD></TR><TR><TD align=center><font color=''#808080''>{date} </font></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></DIV>\r\n\r\n\r\n\r\n<DIV align="left">\r\n{details} <br><br> Writer : <font color=''#808080''>{writer}</font>\r\n</div>\r\n</td></tr>\r\n\r\n</table>   ', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (45, '', 'links_browse_news', 'news_{id}.html', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (46, '', 'links_browse_news_w_pages', 'news_{date}_{start}.html', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (48, 'Email Change confirmation Message', 'email_change_confirmation_msg', '<html>\r\n<body>\r\n\r\nDear {username}  ,<br><br>\r\n\r\nTo Activate Email Change process please open the Following link : <br>\r\n\r\n{active_link}\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (49, 'Password Reset Message', 'pwd_rest_request_msg', '<html>\r\n<body>\r\n\r\nDear {name},<br><br>\r\n\r\nYou Requested Password reset , to complete process plase open the following link : \r\n<br>\r\n{url}\r\n<br><br>\r\n\r\nif you are not who did this request , please just ignore the message.\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (50, 'New Password Message', 'pwd_rest_done_msg', '<html>\r\n<body>\r\n\r\nDear {name},<br>\r\nYour Password changed Successfully , \r\n<br><br>\r\n\r\nYour new Password is : {password}\r\n\r\n\r\n\r\n<br><br><br>\r\n\r\n-------------<br>\r\n{sitename}<br>\r\n{siteurl}\r\n\r\n<br>\r\n</body>\r\n</html>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (53, '', 'links_video_watch', 'video_watch_{id}', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (54, '', 'links_video_download', 'video_download_{id}', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (55, 'Sort Songs Bar', 'songs_orderby', '<?\r\nglobal $phrases,$id,$album_id,$start,$orderby,$op;\r\n\r\nif($op !="letter"){\r\n\r\n$page_string = str_replace(array(''{id}'',''{album_id}'',''{start}''),array($id,$album_id,$start),get_template(''links_browse_songs_w_pages''));\r\n\r\n\r\nprint "<img src=''images/sort.gif''>&nbsp;<b>$phrases[songs_orderby_text] :</b>\r\n\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''name'',''asc''),$page_string)."''>".iif($orderby=="name","<b>")."$phrases[the_name]".iif($orderby=="name","</b>")."</a>\r\n\r\n\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''name'',''asc''),$page_string)."''><img src=''images/arr_asc.gif'' border=0 alt=''$phrases[asc]''></a>\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''name'',''desc''),$page_string)."''><img src=''images/arr_desc.gif'' border=0 alt=''$phrases[desc]''></a>&nbsp;\r\n\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''id'',''asc''),$page_string)."''>".iif($orderby=="id","<b>")."$phrases[add_date]".iif($orderby=="id","</b>")."</a>\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''id'',''asc''),$page_string)."''><img src=''images/arr_asc.gif'' border=0 alt=''$phrases[asc]''></a>\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''id'',''desc''),$page_string)."''><img src=''images/arr_desc.gif'' border=0 alt=''$phrases[desc]''></a>&nbsp\r\n\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''votes'',''desc''),$page_string)."''>".iif($orderby=="votes","<b>")."$phrases[the_most_voted]".iif($orderby=="votes","</b>")."</a>\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''votes'',''asc''),$page_string)."''><img src=''images/arr_asc.gif'' border=0 alt=''$phrases[asc]''></a>\r\n<a href=''".str_replace(array(''{orderby}'',''{sort}''),array(''votes'',''desc''),$page_string)."''><img src=''images/arr_desc.gif'' border=0 alt=''$phrases[desc]''></a>&nbsp\r\n\r\n<br><br>";\r\n}\r\n?>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (56, 'Browse Songs -  Header', 'browse_songs_header', '<?\r\nglobal $settings,$action,$urls_sets,$songs_fields_sets;\r\n\r\nif($action=="songs"){\r\n//----- sort by template ------\r\nif($settings[''visitors_can_sort_songs'']){\r\ncompile_template(get_template("songs_orderby"));\r\n}\r\n//--------------------\r\n\r\n\r\nopen_table();\r\n}\r\n\r\n//--------- Sync URLs Sets -------  \r\n$urls_sets = sync_urls_sets();\r\n//-------- Sync Songs Fields Sets ---------\r\n$songs_fields_sets = sync_songs_fields_sets();\r\n\r\nif($settings[''songs_multi_select'']){\r\nprint "<form name=''songs_form'' action=''songs_process.php'' method=''get''>";\r\n}\r\n\r\nprint "<table width=100%>";\r\n?>\r\n', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (57, 'Browse Songs -  Footer', 'browse_songs_footer', '<?\r\nglobal $action,$global_dir,$settings;\r\nif($settings[''songs_multi_select'']){\r\nprint "<tr><td colspan=8 valign=top>\r\n<img src=''images/arrow_".$global_dir.".gif''> &nbsp;<a href=''#'' onclick=\\"CheckAll(''songs_form''); return false;\\"> Check All</a> -\r\n          <a href=''#'' onclick=\\"UncheckAll(''songs_form''); return false;\\">Uncheck All</a> &nbsp;<img src=''images/arrow_".$global_dir."2.gif''> &nbsp; <a href=''#'' onclick=\\"document.songs_form.submit();\\">Listen to Songs</a>\r\n</td></tr>\r\n</form>";\r\n}\r\nprint "</table>";\r\n\r\nif($action=="songs"){\r\nclose_table();\r\n}\r\n?>', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (60, '', 'links_browse_songs_w_pages', 'singer-{id}-{album_id}-{orderby}-{sort}-{start}.html', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (61, '', 'links_browse_cat', 'cat-{id}.html', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (62, '', 'links_browse_videos', 'videos-{id}.html', 1, 1);
INSERT INTO `songs_templates` (`id`, `title`, `name`, `content`, `protected`, `cat`) VALUES (63, '', 'links_browse_videos_w_pages', 'videos-{id}-{start}.html', 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_templates_cats`
-- 

CREATE TABLE `songs_templates_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `selectable` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `songs_templates_cats`
-- 

INSERT INTO `songs_templates_cats` (`id`, `name`, `selectable`) VALUES (1, 'Default Style', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_urls_data`
-- 

CREATE TABLE `songs_urls_data` (
  `id` int(11) NOT NULL auto_increment,
  `url` text NOT NULL,
  `downloads` int(11) NOT NULL default '0',
  `listens` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  `song_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=104 ;

-- 
-- Dumping data for table `songs_urls_data`
-- 

INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (60, 'http://song7.6arab.com/sara-alhani_E_ftakatak.rm', 0, 0, 1, 98);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (9, 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Hekyo-Eyneyk.rm', 0, 0, 1, 37);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (10, 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Kanet-Rohi.rm', 0, 0, 1, 36);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (11, 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Min-Ghayrak.rm', 0, 0, 1, 35);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (12, 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Haram-Eleyk.rm', 0, 0, 1, 34);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (13, 'http://www.mazikana.com/Songs/R/Rayan/rm/Hekyo_Eyneyk/Mazikana_Rayan---Albi-Ehtar.rm', 1, 0, 1, 33);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (14, 'http://song4.6arab.com/ELISSA_Bastanak.rm', 0, 0, 1, 32);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (15, 'http://www.mazikana.com/Songs/E/Elissa/rm/Bastnak/Mazikana_Elissa---Taa.rm', 0, 0, 1, 31);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (16, 'http://www.mazikana.com/Songs/E/Elissa/rm/Bastnak/Mazikana_Elissa---Kermalak.rm', 0, 0, 1, 30);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (17, 'http://www.mazikana.com/Songs/E/Elissa/rm/Bastnak/Mazikana_Elissa---Fatet-Senen.rm', 0, 0, 1, 29);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (18, 'http://www.mazikana.com/Songs/E/Elissa/rm/Bastnak/Mazikana_Elissa---Baaesh-Ala-Hessak.rm', 0, 0, 1, 28);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (23, 'http://song4.6arab.com/Tamer-7osny_etl3-mn-dol.rm', 0, 0, 1, 50);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (24, 'http://song4.6arab.com/Tamer-7osny_elwa7eda.rm', 0, 0, 1, 51);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (25, 'http://song4.6arab.com/tamer_7osney_ana-wala-3aref.rm', 0, 0, 1, 52);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (26, 'http://song4.6arab.com/tamer_7osney_ana-wala-3aref.rm', 0, 0, 1, 55);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (27, 'http://song.6arab.com/3ady_samedoon.rm', 0, 0, 1, 71);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (28, 'http://songs1.6arab.com/elissa..3ayshalak.rm', 0, 0, 1, 72);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (32, 'http://song5.6arab.com/maged-al-mohandes_enganait.rm', 0, 0, 1, 78);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (33, 'http://song5.6arab.com/maged-al-mohandes_bain-edaya.rm', 0, 0, 1, 79);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (34, 'http://song5.6arab.com/maged-al-mohandes_ganna-ganna.rm', 0, 0, 1, 80);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (35, 'http://song5.6arab.com/maged-al-mohandes_kel-laila.rm', 0, 0, 1, 81);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (36, 'http://song5.6arab.com/maged-al-mohandes_mala2etsh-ella-ana.rm', 1, 0, 1, 82);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (58, 'test.rm', 0, 0, 1, 96);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (57, 'test', 0, 0, 3, 78);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (56, '', 0, 0, 2, 78);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (61, 'http://song7.6arab.com/sara-alhani_A_illi_Nasini.rm', 0, 0, 1, 99);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (62, 'http://song7.6arab.com/sara-alhani_Fadet_Rouhak.rm', 0, 0, 1, 100);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (63, 'http://song7.6arab.com/sara-alhani_A_al_Chou_Aabalou.rm', 0, 0, 1, 101);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (64, 'http://song7.6arab.com/sara-alhani_Olti_Eh.rm', 0, 0, 1, 102);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (65, 'http://song7.6arab.com/sara-alhani_Law_Khayarouni.rm', 0, 0, 1, 103);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (66, 'http://song7.6arab.com/sara-alhani_Ma_Hada_Byebaaedni.rm', 0, 0, 1, 104);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (67, 'http://song7.6arab.com/sara-alhani_Heik_Btaamol.rm', 0, 0, 1, 105);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (68, 'http://song7.6arab.com/adel-almokhtar_Oumi.rm', 0, 0, 1, 106);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (69, 'http://song7.6arab.com/adel-almokhtar_Ana-Wayak.rm', 0, 0, 1, 107);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (70, 'http://song7.6arab.com/adel-almokhtar_Tehin-Li.rm', 0, 0, 1, 108);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (71, 'http://song7.6arab.com/adel-almokhtar_Rouhy-Fi-Rouh.rm', 0, 0, 1, 109);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (72, 'http://song7.6arab.com/adel-almokhtar_Soghiara.rm', 0, 0, 1, 110);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (73, 'http://song7.6arab.com/Samo_Ehsas-Bishedeny.rm', 0, 0, 1, 111);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (74, 'http://song7.6arab.com/Samo_Getlak-Beteak.rm', 0, 0, 1, 112);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (75, 'http://song7.6arab.com/Samo_Khatim-Fi-Edeak.rm', 0, 0, 1, 113);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (76, 'http://song7.6arab.com/Samo_Taleaa-Lemeen.rm', 0, 0, 1, 114);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (77, 'http://song7.6arab.com/Samo_Aaref-Maly.rm', 0, 0, 1, 115);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (78, 'http://song7.6arab.com/Samo_Leek-Lewahdak.rm', 0, 0, 1, 116);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (79, 'http://song.6arab.com/samo_Aref-Eh.rm', 0, 0, 1, 117);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (80, 'http://song.6arab.com/samo_Ayam-Wsenen.rm', 0, 0, 1, 118);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (81, 'http://song.6arab.com/samo_Bahlm-Bek.rm', 0, 0, 1, 119);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (82, 'http://song.6arab.com/samo_Ely-Ma-Bena.rm', 0, 0, 1, 120);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (83, 'http://song7.6arab.com/3asi-El7elany_Elhawa-Thalem.rm', 0, 0, 1, 121);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (84, 'http://song7.6arab.com/3asi-El7elany_Bandah-Ma-Byesma3.rm', 0, 0, 1, 122);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (85, 'http://song7.6arab.com/3asi-El7elany_Boset-Khangar.rm', 0, 0, 1, 123);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (86, 'http://song7.6arab.com/3asi-El7elany_7alet-2laby.rm', 0, 0, 1, 124);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (87, 'http://song7.6arab.com/layal_Aboya-Alley.rm', 0, 1, 1, 125);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (88, 'http://song7.6arab.com/layal_Tshoby.rm', 0, 0, 1, 126);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (89, 'http://song7.6arab.com/layal_Hawasy-Kela.rm', 0, 0, 1, 127);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (90, 'http://song7.6arab.com/layal_Am-Bahlamak.rm', 0, 1, 1, 128);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (91, 'http://song7.6arab.com/Jawaher_Enday.rm', 0, 0, 1, 129);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (92, 'http://song7.6arab.com/Jawaher_Betqoul-Eah.rm', 0, 0, 1, 130);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (93, 'http://song7.6arab.com/Jawaher_Khamsa-We-Khemesa.rm', 0, 0, 1, 131);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (94, 'http://song7.6arab.com/Jawaher_Souq-Ya-Sawaq.rm', 0, 0, 1, 132);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (95, 'http://song7.6arab.com/rami-sabry_El-Kalam-Kolo.rm', 0, 0, 1, 133);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (96, 'http://song7.6arab.com/rami-sabry_3''amat-3einy.rm', 0, 0, 1, 134);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (97, 'http://song7.6arab.com/rami-sabry_Kelma.rm', 0, 0, 1, 135);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (98, 'http://song7.6arab.com/rami-sabry_Mabalash.rm', 0, 0, 1, 136);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (99, 'http://song7.6arab.com/Tamer_Eftra''ana.rm', 0, 0, 1, 137);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (100, 'http://song7.6arab.com/Tamer_-Enta-Meen-Beysd''ak.rm', 0, 0, 1, 138);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (101, 'http://song7.6arab.com/Tamer_Teslam.rm', 0, 0, 1, 139);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (102, 'http://song7.6arab.com/Tamer_Zai-Kol-Mara.rm', 0, 0, 1, 140);
INSERT INTO `songs_urls_data` (`id`, `url`, `downloads`, `listens`, `cat`, `song_id`) VALUES (103, 'http://song7.6arab.com/Tamer_Katar-Kheri.rm', 0, 0, 1, 141);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_urls_fields`
-- 

CREATE TABLE `songs_urls_fields` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `download_icon` text NOT NULL,
  `listen_icon` text NOT NULL,
  `show_listen` int(11) NOT NULL default '0',
  `show_download` int(11) NOT NULL default '0',
  `ord` int(11) NOT NULL default '0',
  `listen_mime` text NOT NULL,
  `listen_name` text NOT NULL,
  `listen_content` text NOT NULL,
  `download_alt` text NOT NULL,
  `listen_alt` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `songs_urls_fields`
-- 

INSERT INTO `songs_urls_fields` (`id`, `name`, `download_icon`, `listen_icon`, `show_listen`, `show_download`, `ord`, `listen_mime`, `listen_name`, `listen_content`, `download_alt`, `listen_alt`, `active`) VALUES (1, 'URL', 'images/save.gif', 'images/listen.gif', 1, 1, 0, 'audio/x-pn-realaudio', 'listen.ram', '<?\r\nglobal $data,$num_ramadv,$scripturl,$settings;\r\nif($num_ramadv){\r\n\r\n$adv_ram_link = "?rpcontexturl=".$scripturl."/ram_banners.php&rpcontextwidth=$settings[ramadv_width]&rpcontextheight=$settings[ramadv_height]";\r\n\r\n}else{\r\n$adv_ram_link = "";\r\n}\r\n\r\nif (strchr($data[''url''],"http://")) {\r\n print "$data[url]".$adv_ram_link;\r\n           }else{\r\n print $scripturl."/".$data[''url''].$adv_ram_link;\r\n        }\r\n?>', 'Download ({downloads} downloads)', 'Listen ({listens} listens)', 1);
INSERT INTO `songs_urls_fields` (`id`, `name`, `download_icon`, `listen_icon`, `show_listen`, `show_download`, `ord`, `listen_mime`, `listen_name`, `listen_content`, `download_alt`, `listen_alt`, `active`) VALUES (7, 'Mp3 URL', 'images/save.gif', 'images/listen.gif', 1, 1, 1, 'audio/x-pn-realaudio', 'listen.ram', '<?\r\nglobal $data,$num_ramadv,$scripturl,$settings;\r\nif($num_ramadv){\r\n\r\n$adv_ram_link = "?rpcontexturl=".$scripturl."/ram_banners.php&rpcontextwidth=$settings[ramadv_width]&rpcontextheight=$settings[ramadv_height]";\r\n\r\n}else{\r\n$adv_ram_link = "";\r\n}\r\n\r\nif (strchr($data[''url''],"http://")) {\r\n print "$data[url]".$adv_ram_link;\r\n           }else{\r\n print $scripturl."/".$data[''url''].$adv_ram_link;\r\n        }\r\n?>', 'Download Mp3 ({downloads} downloads)', 'Listen Mp3 ({listens} listens)', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_user`
-- 

CREATE TABLE `songs_user` (
  `id` int(11) NOT NULL auto_increment,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `email` text NOT NULL,
  `group_id` int(11) NOT NULL default '0',
  `permisions` text NOT NULL,
  `permisions_videos` text NOT NULL,
  `cp_permisions` text NOT NULL,
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `songs_user`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `songs_videos_cats`
-- 

CREATE TABLE `songs_videos_cats` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `img` text NOT NULL,
  `cat` int(11) NOT NULL default '0',
  `type` text NOT NULL,
  `ord` int(11) NOT NULL default '0',
  `active` int(11) NOT NULL default '0',
  `download_limit` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `songs_videos_cats`
-- 

INSERT INTO `songs_videos_cats` (`id`, `name`, `img`, `cat`, `type`, `ord`, `active`, `download_limit`) VALUES (1, 'English Videos', '', 0, 'clips', 1, 1, 0);
INSERT INTO `songs_videos_cats` (`id`, `name`, `img`, `cat`, `type`, `ord`, `active`, `download_limit`) VALUES (2, 'Arabic Videos', '', 0, 'clips', 0, 1, 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_videos_data`
-- 

CREATE TABLE `songs_videos_data` (
  `id` int(11) NOT NULL auto_increment,
  `cat` int(11) NOT NULL default '0',
  `name` text NOT NULL,
  `url` text NOT NULL,
  `img` text NOT NULL,
  `downloads` int(11) NOT NULL default '0',
  `views` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `votes` int(11) NOT NULL default '0',
  `votes_total` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=22 ;

-- 
-- Dumping data for table `songs_videos_data`
-- 

INSERT INTO `songs_videos_data` (`id`, `cat`, `name`, `url`, `img`, `downloads`, `views`, `date`, `votes`, `votes_total`) VALUES (18, 2, 'Tamer Ashour - Teslm', 'test.rm', 'uploads/videos/tashour-teslam_138.jpg', 0, '', '2008-12-13 06:39:24', 4, 1);
INSERT INTO `songs_videos_data` (`id`, `cat`, `name`, `url`, `img`, `downloads`, `views`, `date`, `votes`, `votes_total`) VALUES (20, 2, 'Rouby - Yal Rumosh', 'test.rm', 'uploads/videos/ruby-yalromoush_121.jpg', 0, '1', '2008-12-13 06:41:18', 1, 1);
INSERT INTO `songs_videos_data` (`id`, `cat`, `name`, `url`, `img`, `downloads`, `views`, `date`, `votes`, `votes_total`) VALUES (19, 2, 'Samo Zean - Ayez Meny Eh', 'test.rm', 'uploads/videos/samo-ayzmenieh_684.jpg', 0, '', '2008-12-13 06:40:26', 3, 1);
INSERT INTO `songs_videos_data` (`id`, `cat`, `name`, `url`, `img`, `downloads`, `views`, `date`, `votes`, `votes_total`) VALUES (21, 2, 'Haifa Wehby - Yabn El Halal', 'test.rm', 'uploads/videos/haifa-ybn7lal_769.jpg', 0, '', '2008-12-13 06:41:55', 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_votes`
-- 

CREATE TABLE `songs_votes` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `cnt` int(11) NOT NULL default '0',
  `cat` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=4 ;

-- 
-- Dumping data for table `songs_votes`
-- 

INSERT INTO `songs_votes` (`id`, `title`, `cnt`, `cat`) VALUES (1, 'Good', 27, 1);
INSERT INTO `songs_votes` (`id`, `title`, `cnt`, `cat`) VALUES (2, 'Normal', 2, 1);
INSERT INTO `songs_votes` (`id`, `title`, `cnt`, `cat`) VALUES (3, 'Bad', 1, 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `songs_votes_cats`
-- 

CREATE TABLE `songs_votes_cats` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `active` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
)  AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `songs_votes_cats`
-- 

INSERT INTO `songs_votes_cats` (`id`, `title`, `active`) VALUES (1, 'What are you think about website ?', 1);
